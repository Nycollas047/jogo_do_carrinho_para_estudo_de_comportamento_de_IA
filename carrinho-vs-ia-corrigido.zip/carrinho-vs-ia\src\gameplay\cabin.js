// Cabine: para-brisa embaçado e limpador. Lógica pura (sem DOM, sem Three.js).
//
// Regra de jogo: a névoa SÓ aparece na chuva (e na neblina). O limpador (Círculo)
// limpa de verdade nesses climas; a seco ele apenas range e não muda nada.
// A visibilidade final do jogador é 1 - fog: é isso que o overlay e o HUD usam.
import { CONFIG } from '../core/config.js';

export class Cabin {
  constructor() {
    this.fog = 0;          // 0 (limpo) a 1 (opaco)
    this.droplets = 0;     // gotas acumuladas no vidro
    this.wiperPhase = 0;   // 0..1 dentro de uma varredura
    this.wiperActive = false;
    this.wiperTicks = 0;   // inversões de curso (o "clac")
    this.dryWiperTime = 0; // tempo de limpador a seco (rangido)
  }

  static isRainy(weather) {
    return weather?.id === 'chuva' || weather?.id === 'neblina';
  }

  reset() {
    this.fog = 0;
    this.droplets = 0;
    this.wiperPhase = 0;
    this.wiperActive = false;
    this.wiperTicks = 0;
    this.dryWiperTime = 0;
  }

  // weather, speed (m/s), wiperOn (deve ser true enquanto segurar Círculo)
  update(dt, { weather = null, speed = 0, wiperOn = false } = {}) {
    const c = CONFIG.cabin;
    const rainy = Cabin.isRainy(weather);
    this.wiperActive = !!wiperOn;
    let tick = false;

    if (rainy) {
      const gain = c.fogRain + c.fogSpeed * Math.abs(speed);
      this.fog = Math.min(c.fogMax, this.fog + gain * dt);
      this.droplets = Math.min(1, this.droplets + (0.2 + Math.abs(speed) * 0.012) * dt);
    } else {
      this.fog = Math.max(0, this.fog - c.dryRate * dt);
      this.droplets = Math.max(0, this.droplets - c.dryRate * 1.5 * dt);
    }

    if (this.wiperActive) {
      if (rainy) {
        this.fog = Math.max(0, this.fog - c.wiperClear * dt);
        this.droplets = Math.max(0, this.droplets - c.wiperClear * 1.4 * dt);
        this.dryWiperTime = 0;
      } else {
        // A seco não limpa nada — só desgasta a borracha (e range)
        this.dryWiperTime += dt;
      }

      const prev = this.wiperPhase;
      this.wiperPhase = (this.wiperPhase + dt / c.wiperPeriod) % 1;
      if (this.wiperPhase < prev) {
        this.wiperTicks += 1;
        tick = true; // inversão de curso
      }
    } else {
      this.dryWiperTime = 0;
      // Volta suave para a posição de repouso
      const rest = dt / (c.wiperPeriod * 0.5);
      this.wiperPhase = this.wiperPhase > 1 - rest ? 0 : Math.min(1, this.wiperPhase + rest);
    }

    return { tick, rainy };
  }

  // 0 = vidro limpo, 1 = totalmente embaçado
  get visibility() {
    return Math.max(0, 1 - this.fog);
  }

  // Fração de visão perdida (o que o overlay desenha)
  get blur() {
    return this.fog;
  }
}
