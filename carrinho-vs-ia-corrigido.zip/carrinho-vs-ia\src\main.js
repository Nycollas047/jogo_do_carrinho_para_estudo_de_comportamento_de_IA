// Ponto de entrada: monta o mundo, liga lógica e visual, e roda o loop.
// Ordem: núcleo → mundo → veículos → partida → visual → loop.
import * as THREE from 'three';
import { CONFIG, WEATHER } from './core/config.js';
import { EventBus } from './core/events.js';
import { createRng } from './core/random.js';
import { Terrain } from './world/terrain.js';
import { Props } from './world/props.js';
import { CoinField } from './world/coins.js';
import { Train } from './world/train.js';
import { Vehicle } from './vehicles/vehicle.js';
import { PlayerDriver, AIDriver } from './vehicles/drivers.js';
import { Input, isDualSensePad, diagnoseInput, describeInputHealth } from './input/input.js';
import { HapticController } from './haptics/haptics.js';
import { Match } from './gameplay/match.js';
import { Cabin } from './gameplay/cabin.js';
import { Hud } from './ui/hud.js';
import { buildTerrainMesh, buildApron } from './render/terrainView.js';
import { buildRoadGroup, buildRailGroup } from './render/trackView.js';
import { buildProps } from './render/propsView.js';
import { buildVehicleMesh, syncVehicleMesh } from './render/vehicleView.js';
import { buildTrainMeshes, syncTrainMeshes } from './render/trainView.js';
import { buildDelineators, buildSignals } from './render/roadsideView.js';
import { CoinView, COIN_COLORS } from './render/coinView.js';
import { WeatherView } from './render/weatherView.js';
import { CabinView } from './render/cabinView.js';
import { Sky } from './render/sky.js';
import { SoundSystem } from './audio/sound.js';
import { ParticleSystem } from './render/particles.js';

const STEP = 1 / 60; // passo fixo de simulação

// ---------- 1. Núcleo e lógica ----------
const bus = new EventBus();
const terrain = new Terrain(CONFIG.seed);

const props = new Props(terrain);
props.generate(createRng(CONFIG.seed + 1)); // cenário fixo em todas as rodadas

const coins = new CoinField(terrain, props);
coins.reset(createRng(CONFIG.seed + 2)); // moedas já visíveis antes de começar

const train = new Train(terrain);
const input = new Input();
const haptics = new HapticController(bus);
const hud = new Hud();
const cabin = new Cabin();

const player = new Vehicle({ id: 'player', terrain, driver: new PlayerDriver(input) });
const ai = new Vehicle({
  id: 'ai',
  terrain,
  driver: new AIDriver({
    terrain,
    props,
    getCoins: () => coins.coins,
    getHazards: () => match.signals,
    getLead: () => match.scores.ai - match.scores.player,
  }),
});

const match = new Match({ bus, terrain, coins, props, train, player, ai });

// ---------- 2. Visual ----------
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 900);

const sky = new Sky(scene);
const hemi = new THREE.HemisphereLight(0xffffff, 0x4a5a2a, 0.6);
const sun = new THREE.DirectionalLight(0xfff4e0, 1.2);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, { left: -90, right: 90, top: 90, bottom: -90, near: 1, far: 400 });
sun.shadow.bias = -0.0008;
scene.add(hemi, sun, sun.target);

const terrainMesh = buildTerrainMesh(terrain);
scene.add(terrainMesh, buildApron(), buildRoadGroup(terrain), buildRailGroup(terrain), buildProps(props, terrain));

const vehicleMeshes = {
  player: buildVehicleMesh(0xe74c3c),
  ai: buildVehicleMesh(0x3498db),
};
scene.add(vehicleMeshes.player, vehicleMeshes.ai);

scene.add(buildDelineators(terrain));
const signalView = buildSignals(terrain, train.crossings);
scene.add(signalView.group);

const trainView = buildTrainMeshes();
scene.add(trainView.group);

const coinView = new CoinView(scene);
const weatherView = new WeatherView(scene, sun, hemi, sky);
weatherView.apply(WEATHER[0]);

// Overlay da cabine (embaçamento + limpador). Só desenha na chuva/neblina.
const cabinView = new CabinView();

// Água: um plano translúcido no nível calculado pelo terreno. As bacias enchem;
// o terreno acima do nível oculta o plano, então não é preciso recortar nada.
const waterMat = new THREE.MeshLambertMaterial({
  color: 0x2f6f96,
  transparent: true,
  opacity: 0.72,
  emissive: 0x0a2233,
});
const waterMesh = new THREE.Mesh(
  new THREE.PlaneGeometry(CONFIG.world.size, CONFIG.world.size),
  waterMat
);
waterMesh.rotation.x = -Math.PI / 2;
waterMesh.position.y = terrain.waterLevel;
waterMesh.receiveShadow = false;
scene.add(waterMesh);

// Faróis: dois refletores presos ao carro do jogador
function addHeadlights(group) {
  const lights = [];
  for (const x of [-0.62, 0.62]) {
    const spot = new THREE.SpotLight(CONFIG.lights.beamColor, 0, 70, Math.PI / 7, 0.45, 1.2);
    spot.position.set(x, 0.85, 1.9);
    const target = new THREE.Object3D();
    target.position.set(x * 1.4, 0.1, 16);
    group.add(spot, target);
    spot.target = target;
    lights.push(spot);
  }
  return lights;
}
const headlights = addHeadlights(vehicleMeshes.player);

const sound = new SoundSystem();
const particles = new ParticleSystem(scene);

// Eventos que o visual e o áudio reagem (a lógica não sabe que eles existem)
bus.on('weather:change', ({ profile }) => weatherView.apply(profile));
bus.on('match:start', () => sound.resume());
bus.on('match:resume', () => sound.resume());
bus.on('match:end', () => haptics.stop());
bus.on('match:end', () => hud.showStart('Próxima rodada'));

bus.on('coin:collected', ({ vehicle, value, coin }) => {
  if (vehicle.id === 'player') sound.playCoin(value);
  const coinY = terrain.heightAt(coin.x, coin.z) + 1.0;
  particles.burstCoin(coin.x, coinY, coin.z, COIN_COLORS[value] ?? 0xffd23f);
});

bus.on('vehicle:bump', ({ vehicle, impact }) => {
  if (vehicle.id === 'player') sound.playBump(impact);
});

bus.on('vehicle:crash', ({ vehicle }) => {
  if (vehicle.id === 'player') sound.playCrash();
});

// ---------- 3. Entrada, tela inicial e câmera ----------
function updateHidUi() {
  const btn = document.getElementById('hid-connect');
  const startHidBtn = document.getElementById('start-hid-btn');
  if (haptics.dualSense.connected) {
    const text = `DualSense Conectado (${haptics.dualSense.link.toUpperCase()})`;
    if (btn) {
      btn.textContent = text;
      btn.style.borderColor = 'rgba(52,211,153,0.6)';
      btn.style.color = '#a7f3d0';
    }
    if (startHidBtn) {
      startHidBtn.textContent = text;
      startHidBtn.style.borderColor = 'rgba(52,211,153,0.6)';
      startHidBtn.style.color = '#a7f3d0';
    }
  } else {
    const text = 'Conectar DualSense (USB/BT)';
    if (btn) {
      btn.textContent = text;
      btn.style.borderColor = 'rgba(255,255,255,0.25)';
      btn.style.color = '#fff';
    }
    if (startHidBtn) {
      startHidBtn.textContent = 'Conectar DualSense';
      startHidBtn.style.borderColor = 'rgba(255,255,255,0.25)';
      startHidBtn.style.color = '#fff';
    }
  }
}

const hidConnectBtn = document.getElementById('hid-connect');
if (hidConnectBtn) {
  hidConnectBtn.addEventListener('click', async () => {
    hidConnectBtn.blur?.();
    sound.resume();
    await haptics.connectDualSense();
    updateHidUi();
    if (haptics.dualSense.connected) {
      hud.hideStart();
      if (match.state === 'ready' || match.state === 'ended') match.start();
      else if (match.state === 'paused') match.resume();
    }
  });
}

const startHidBtn = document.getElementById('start-hid-btn');
if (startHidBtn) {
  startHidBtn.addEventListener('click', async () => {
    startHidBtn.blur?.();
    sound.resume();
    await haptics.connectDualSense();
    updateHidUi();
    if (haptics.dualSense.connected) {
      hud.hideStart();
      if (match.state === 'ready' || match.state === 'ended') match.start();
      else if (match.state === 'paused') match.resume();
    }
  });
}

const startBtn = document.getElementById('start-btn');
if (startBtn) {
  startBtn.addEventListener('click', async () => {
    startBtn.blur?.();
    sound.resume();
    hud.hideStart();
    if (match.state === 'ready' || match.state === 'ended') match.start();
    if (haptics.dualSense.supported && !haptics.dualSense.connected) {
      await haptics.reconnectDualSense();
      updateHidUi();
    }
    haptics.test();
  });
}

window.addEventListener('pointerdown', () => sound.resume(), { passive: true });
window.addEventListener('keydown', (e) => {
  sound.resume();
  if (e.code === 'F2') hud.toggleDebug();
  if (e.code === 'F3') haptics.test(); // vibração de teste
});

// Reutiliza a autorização WebHID dada anteriormente (sem abrir seletor).
haptics.reconnectDualSense().then(() => updateHidUi());

window.addEventListener('gamepadconnected', (e) => {
  if (isDualSensePad(e.gamepad) && haptics.dualSense.supported && !haptics.dualSense.connected) {
    haptics.reconnectDualSense().then(() => updateHidUi());
  }
});

// Perdeu o foco (trocou de aba): pausa, para o carro não andar sozinho
document.addEventListener('visibilitychange', () => {
  if (document.hidden) match.pause();
});

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

const camTarget = new THREE.Vector3();
const camDesired = new THREE.Vector3();
let cameraReady = false;

let devCam = null; // câmera livre, só para o modo ?dev (inspeção visual)

let camFov = CONFIG.camera.fov;

function updateCamera(dt) {
  if (devCam) {
    camera.position.copy(devCam.pos);
    camera.lookAt(devCam.look);
    return;
  }
  const { distance, height, lerp, fov, fovBoost } = CONFIG.camera;

  // Campo de visão abre com a velocidade (sensação de velocidade sem mudar a física)
  const speedRatio = Math.min(1, Math.abs(player.speed) / CONFIG.vehicle.maxSpeed);
  camFov += (fov + fovBoost * speedRatio * speedRatio - camFov) * Math.min(1, dt * 4);
  if (Math.abs(camera.fov - camFov) > 0.01) {
    camera.fov = camFov;
    camera.updateProjectionMatrix();
  }

  // Analógico direito gira a câmera em volta do carro; R3 olha para trás
  const h = player.heading + input.readCamera(dt);
  camDesired.set(
    player.x - Math.sin(h) * distance,
    player.y + height,
    player.z - Math.cos(h) * distance
  );
  // A câmera nunca entra no relevo: fica pelo menos 2 m acima do chão
  camDesired.y = Math.max(camDesired.y, terrain.heightAt(camDesired.x, camDesired.z) + 2);

  if (!cameraReady) {
    camera.position.copy(camDesired);
    cameraReady = true;
  } else {
    // O quanto a câmera acompanha não depende da taxa de quadros
    camera.position.lerp(camDesired, 1 - Math.pow(1 - lerp, dt * 60));
  }
  camTarget.set(player.x, player.y + 1.2, player.z);
  camera.lookAt(camTarget);
}

// Sol e sombras acompanham o carro (a sombra só precisa cobrir a área perto dele)
function updateSun() {
  sun.position.set(player.x + 60, 120, player.z + 40);
  sun.target.position.set(player.x, 0, player.z);
  sun.target.updateMatrixWorld();
}

// Seta para a melhor moeda (valor alto e perto) e alerta de trem
function updateHudExtras(hazard) {
  if (match.state !== 'playing') {
    hud.setArrow(null);
    hud.setWarning(null);
    return;
  }
  let best = null;
  let bestScore = 0;
  for (const c of coins.coins) {
    const d = Math.hypot(c.x - player.x, c.z - player.z);
    const score = c.value / (d + 25);
    if (score > bestScore) {
      best = { c, d };
      bestScore = score;
    }
  }
  if (best) {
    // Ângulo em relação ao que a câmera está vendo (não ao carro)
    const fx = player.x - camera.position.x;
    const fz = player.z - camera.position.z;
    const fl = Math.hypot(fx, fz) || 1;
    const tx = best.c.x - player.x;
    const tz = best.c.z - player.z;
    const forward = (tx * fx + tz * fz) / fl;
    const side = (tx * -fz + tz * fx) / fl;
    hud.setArrow({
      angle: Math.atan2(side, forward),
      dist: best.d,
      value: best.c.value,
      color: '#' + COIN_COLORS[best.c.value].toString(16).padStart(6, '0'),
    });
  } else hud.setArrow(null);

  if (hazard && hazard.dist < 110) {
    const urgent = hazard.state === 'red';
    hud.setWarning(urgent ? `TREM NO CRUZAMENTO · ${Math.round(hazard.dist)} m` : `TREM CHEGANDO · cruzamento a ${Math.round(hazard.dist)} m`, urgent);
  } else hud.setWarning(null);
}

// ---------- 4. Loop principal ----------
let lastTime = performance.now() / 1000;
let accumulator = 0;
let lastDebug = 0;

function frame(nowMs) {
  const now = nowMs / 1000;
  const frameTime = Math.min(0.1, now - lastTime);
  lastTime = now;
  accumulator += frameTime;

  // Botões de um toque: Options/Enter começa e pausa; Triângulo é farol (toque)
  // ou voltar à pista (segurar); Círculo é o limpador (segurar).
  const act = input.poll(frameTime);
  if (match.state === 'playing') {
    if (act.pause) match.pause();
    else if (act.reset) match.resetToRoad(player);

    if (act.lights) {
      player.cycleLights();
      bus.emit('vehicle:lights', { vehicle: player, state: player.lights });
    }
    if (act.shiftUp) player.shiftUp();
    if (act.shiftDown) player.shiftDown();
    if (act.autoGear) player.toggleAuto();
  } else if (match.state === 'paused') {
    if (act.confirm || act.pause || act.drive) {
      sound.resume();
      match.resume();
    }
  } else if (match.state === 'ready') {
    if (act.confirm || act.drive) {
      sound.resume();
      hud.hideStart();
      match.start();
    }
  } else if (match.state === 'ended') {
    if (act.confirm) {
      sound.resume();
      hud.hideStart();
      match.start();
    }
  }

  while (accumulator >= STEP) {
    match.update(STEP);
    accumulator -= STEP;
  }
  if (match.state !== 'playing') accumulator = 0; // pausado: não acumula tempo

  // Visual e háptica leem o estado; não alteram a lógica
  syncVehicleMesh(vehicleMeshes.player, player, frameTime);
  syncVehicleMesh(vehicleMeshes.ai, ai, frameTime);
  syncTrainMeshes(trainView, train.getCars());
  coinView.sync(coins.coins, terrain, now);
  signalView.update(match.signals, now);

  // Áudio procedural e partículas dinâmicas
  sound.update(player, match, now, frameTime);
  particles.update(frameTime);

  const absPlayerSlip = Math.abs(player.slip);
  if (absPlayerSlip > 1.2 && Math.abs(player.speed) > 2) {
    particles.emitDrift(player.x, player.y, player.z, player.surface, absPlayerSlip / 4);
  }
  const absAiSlip = Math.abs(ai.slip);
  if (absAiSlip > 1.4 && Math.abs(ai.speed) > 2) {
    particles.emitDrift(ai.x, ai.y, ai.z, ai.surface, absAiSlip / 5);
  }

  const hazard = match.state === 'playing' ? match.hazardFor(player) : null;
  const trainNear = hazard && hazard.dist < 70 ? 1 - hazard.dist / 70 : 0;

  // Cabine: névoa e limpador (só a chuva e a neblina embaçam o vidro)
  const wiperOn = act.wiper && match.state === 'playing';
  cabin.update(frameTime, { weather: match.weather, speed: player.speed, wiperOn });

  // Faróis: intensidade pelo estado. À noite/neblina sem farol a visão encurta de verdade.
  const beam = player.lights === 2 ? CONFIG.lights.high : player.lights === 1 ? CONFIG.lights.low : 0;
  for (const h of headlights) h.intensity = beam;
  if (scene.fog) {
    const darkish =
      match.weather.night || match.weather.id === 'neblina' || match.weather.id === 'chuva';
    const lightFactor = darkish ? 1.45 - 0.45 * (player.lights / 2) : 1;
    scene.fog.density = match.weather.fog * lightFactor;
  }

  haptics.update(now, player, match.weather, trainNear, cabin);
  cabinView.render(cabin);
  weatherView.update(frameTime, camTarget);
  sky.follow(camera.position);
  updateSun();
  updateCamera(frameTime);
  hud.update(match, player, cabin);
  updateHudExtras(hazard);

  if (now - lastDebug > 0.5) {
    lastDebug = now;
    haptics.refresh();
    updateHidUi();
    const s = haptics.status;
    const ctrl = player.controls || { throttle: 0, brake: 0, steer: 0 };
    const rows = diagnoseInput();
    const padLines = rows.length
      ? rows
          .map(
            (r) =>
              `  ${r.source.padEnd(7)} ${r.mapping.padEnd(9)} acel ${r.throttle.toFixed(2)} freio ${r.brake.toFixed(2)} dir ${r.steer.toFixed(2)}  ` +
              `mudo há ${(r.ageMs / 1000).toFixed(1)}s  ${r.id.slice(0, 34)}`
          )
          .join('\n')
      : '  (nenhum controle visível)';
    hud.setDebug(
      `ENTRADA (por que o carro anda ou não)\n` +
      `${describeInputHealth(rows)}\n` +
      padLines + '\n' +
      `\nVEÍCULO\n` +
      `marcha:          ${player.gear === -1 ? 'R' : player.gear} (${player.autoShift ? 'automático' : 'manual'})  ${Math.round(player.rpm)} rpm\n` +
      `piso efetivo:    ${player.ground?.label ?? player.surface}  (grip ${(player.ground?.grip ?? 0).toFixed(2)}, vel ${(player.ground?.speedFactor ?? 0).toFixed(2)})\n` +
      `água:            ${terrain.waterDepthAt(player.x, player.z) > 0 ? terrain.waterDepthAt(player.x, player.z).toFixed(2) + ' m de profundidade' : 'fora da água'}\n` +
      `farol:           ${player.lights === 2 ? 'alto' : player.lights === 1 ? 'baixo' : 'desligado'}\n` +
      `\nCABINE\n` +
      `névoa:           ${(cabin.fog * 100).toFixed(0)}%   gotas: ${(cabin.droplets * 100).toFixed(0)}%\n` +
      `limpador:        ${cabin.wiperActive ? 'ligado' : 'desligado'}  (varreduras: ${cabin.wiperTicks})\n` +
      `clima embaça:    ${Cabin.isRainy(match.weather) ? 'sim' : 'não'}\n` +
      `\nCONTROLE E VIBRAÇÃO\n` +
      `dispositivo:     ${input.lastDevice}\n` +
      `acel / freio:    ${ctrl.throttle.toFixed(2)} / ${ctrl.brake.toFixed(2)} (dir: ${ctrl.steer.toFixed(2)})\n` +
      `atuador:         ${s.actuator}\n` +
      `WebHID:          ${s.webhid}  (relatórios: ${haptics.dualSense.inputReports ?? 0})\n` +
      `clique na página: ${s.activation ? 'sim' : 'NÃO (clique no botão Começar)'}\n` +
      `último resultado: ${s.lastResult}\n` +
      `ok / falhas:     ${s.okCount} / ${s.errCount}\n` +
      `último erro:     ${s.lastError || '—'}\n` +
      `\nF3: vibração de teste`
    );
  }

  renderer.render(scene, camera);
  requestAnimationFrame(frame);
}

// Modo de desenvolvimento: ?dev expõe o estado do jogo no console (window.game)
if (new URLSearchParams(location.search).has('dev')) {
  window.game = {
    player, ai, train, match, coins, camera,
    setDevCam: (pos, look) => { devCam = pos ? { pos: new THREE.Vector3(...pos), look: new THREE.Vector3(...look) } : null; },
  };
}

requestAnimationFrame(frame);



