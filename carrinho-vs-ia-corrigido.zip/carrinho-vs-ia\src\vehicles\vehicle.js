// Veículo (lógica, sem Three.js).
// Não sabe quem dirige: recebe controles de um Driver (jogador ou IA).
// Convenção: heading 0 = +Z; direção = (sin h, cos h). steer > 0 = esquerda.
//
// Modelo de movimento:
//   - A velocidade é um VETOR no mundo (vx, vz), separado da direção do carro (heading).
//   - Componente "para frente" (speed): acelera e freia.
//   - Componente "lateral" (slip): decai pelo agarre. Chuva, neve, lama e o freio de mão
//     reduzem o agarre, então o carro escorrega. Isso faz o clima importar na direção.
//   - Giro: a taxa cai com a velocidade, para a aceleração lateral nunca passar de aLatMax.
import { CONFIG } from '../core/config.js';
import { effectiveSurface } from '../core/surfaces.js';

const approach = (value, target, maxDelta) => {
  if (value < target) return Math.min(value + maxDelta, target);
  return Math.max(value - maxDelta, target);
};

const wrap = (a) => Math.atan2(Math.sin(a), Math.cos(a));

// Curva de torque: interpolação linear na tabela [rpm, fator]
export function torqueAt(rpm) {
  const pts = CONFIG.gearbox.torque;
  if (rpm <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) {
    if (rpm <= pts[i][0]) {
      const [r0, t0] = pts[i - 1];
      const [r1, t1] = pts[i];
      return t0 + ((t1 - t0) * (rpm - r0)) / (r1 - r0);
    }
  }
  return pts[pts.length - 1][1];
}

// Velocidade do carro para um RPM em uma relação total (marcha × diferencial)
export function speedAtRpm(rpm, ratio, gb = CONFIG.gearbox) {
  const wheelRpm = rpm / (ratio * gb.finalDrive);
  return (wheelRpm * 2 * Math.PI * gb.wheelRadius) / 60;
}

export class Vehicle {
  constructor({ id, terrain, driver }) {
    this.id = id;
    this.terrain = terrain;
    this.driver = driver;

    this.x = 0;
    this.y = 0;
    this.z = 0;
    this.heading = 0;
    this.vx = 0;          // velocidade no mundo
    this.vz = 0;
    this.speed = 0;       // componente para frente (m/s, negativo = ré)
    this.slip = 0;        // componente lateral (m/s)
    this.pitch = 0;
    this.roll = 0;
    this.slope = 0;
    this.surface = 'asfalto';
    this.ground = effectiveSurface('asfalto', null); // perfil efetivo (piso + clima)
    this.handbrake = false;
    this.stunTimer = 0;
    this.crashCooldown = 0;
    this.bumpCooldown = 0;
    this.resetCooldown = 0;

    // Câmbio
    this.gear = 1;                       // -1 = ré, 1..5
    this.rpm = CONFIG.gearbox.idleRpm;
    this.shiftTimer = 0;                 // embreagem aberta: sem força
    this.autoShift = CONFIG.gearbox.auto;
    this.gearShift = null;               // { from, to, up } consumido pela partida

    // Faróis: 0 desligado, 1 baixo, 2 alto
    this.lights = 0;
  }

  place(x, z, heading) {
    this.x = x;
    this.z = z;
    this.heading = heading;
    this.vx = 0;
    this.vz = 0;
    this.speed = 0;
    this.slip = 0;
    this.stunTimer = 0;
    this.crashCooldown = 0;
    this.bumpCooldown = 0;
    this.handbrake = false;
    this.y = this.terrain.heightAt(x, z) + CONFIG.vehicle.lift;
  }

  get stunned() {
    return this.stunTimer > 0;
  }

  _scaleVelocity(f) {
    this.vx *= f;
    this.vz *= f;
    this.speed *= f;
    this.slip *= f;
  }

  stun(seconds) {
    this.stunTimer = Math.max(this.stunTimer, seconds);
    this._scaleVelocity(0.2);
  }

  // Batida em obstáculo: perde velocidade
  bump(factor = 0.4) {
    this._scaleVelocity(factor);
  }

  // Contato com um obstáculo, com a normal (nx, nz) apontando do obstáculo para o carro.
  // Em vez de multiplicar a velocidade a cada quadro (o carro "grudava" no poste),
  // remove só a parte da velocidade que entra no obstáculo. O resto desliza pela lateral.
  // Devolve a velocidade de impacto (m/s) para a háptica e as regras.
  contact(nx, nz) {
    const into = this.vx * nx + this.vz * nz;
    if (into >= 0) return 0; // já está se afastando
    const e = 0.15; // quique pequeno
    this.vx -= (1 + e) * into * nx;
    this.vz -= (1 + e) * into * nz;
    // Atrito do encosto: perde um pouco da velocidade lateral
    const f = 1 - Math.min(0.25, -into * 0.02);
    this.vx *= f;
    this.vz *= f;
    this._syncAxes();
    return -into;
  }

  // Recalcula speed e slip a partir do vetor velocidade
  _syncAxes() {
    const fx = Math.sin(this.heading);
    const fz = Math.cos(this.heading);
    this.speed = this.vx * fx + this.vz * fz;
    this.slip = this.vx * fz - this.vz * fx;
  }

  update(dt, weather) {
    const c = CONFIG.vehicle;
    const gb = CONFIG.gearbox;
    const t = this.terrain;

    this.surface = t.surfaceAt(this.x, this.z);
    // Perfil efetivo: o clima entra aqui (chuva molha, neve congela)
    const eff = effectiveSurface(this.surface, weather);
    this.ground = eff;
    let grip = eff.grip;

    if (this.crashCooldown > 0) this.crashCooldown -= dt;
    if (this.bumpCooldown > 0) this.bumpCooldown -= dt;
    if (this.resetCooldown > 0) this.resetCooldown -= dt;
    if (this.shiftTimer > 0) this.shiftTimer -= dt;

    // 1) Controles (sem controle enquanto atordoado)
    let controls = { throttle: 0, brake: 0, steer: 0, handbrake: false };
    if (this.stunTimer > 0) this.stunTimer -= dt;
    else controls = this.driver.controls(this, dt);
    const { throttle, brake, steer } = controls;
    this.controls = controls;
    this.handbrake = !!controls.handbrake;

    // 2) Câmbio e RPM (a marcha define a força disponível já neste quadro)
    this._updateGearbox(dt, throttle);

    // Aquaplanagem: na água, acima da velocidade crítica o pneu perde o que restava
    if (eff.aquaplane < Infinity && Math.abs(this.speed) > eff.aquaplane) {
      grip *= 0.55;
    }

    // 3) Giro: a taxa máxima cai com a velocidade (aceleração lateral limitada)
    const absV = Math.abs(this.speed);
    const yawMax = Math.min(c.steerRate, c.aLatMax / Math.max(absV, 1));
    const speedGate = Math.min(1, absV / 3); // não gira parado
    const understeer = Math.min(1, 0.5 + grip * 0.6); // pouco agarre: curva menos
    const yaw = steer * yawMax * speedGate * understeer * (this.speed >= 0 ? 1 : -1);
    this.heading = wrap(this.heading + yaw * dt);

    // 4) Decompõe a velocidade nos eixos do carro
    const fx = Math.sin(this.heading);
    const fz = Math.cos(this.heading);
    const rx = Math.cos(this.heading);
    const rz = -Math.sin(this.heading);
    let vF = this.vx * fx + this.vz * fz;
    let vL = this.vx * rx + this.vz * rz;

    // 5) Acelerar e frear ao longo do carro. A força vem do torque na marcha atual,
    // e a velocidade máxima da marcha vem do redline — é isso que faz o câmbio existir.
    const slopePenalty = 1 - Math.min(0.6, Math.max(0, this.slope) * 1.5);
    const topSpeed = c.maxSpeed * eff.speedFactor * slopePenalty;
    const ratio = this.gearRatio();
    const gearMax = Math.min(topSpeed, speedAtRpm(gb.redline, ratio));
    const clutchOpen = this.shiftTimer > 0;

    let target = 0;
    let rate = c.drag;
    if (throttle > 0) {
      // O acelerador vira FORÇA, não teto de velocidade: com meio acelerador o carro
      // acelera menos, mas ainda chega ao fim da marcha (senão nunca trocaria de marcha).
      target = gearMax;
      rate = clutchOpen
        ? 0 // troca de marcha: embreagem aberta, sem força
        : c.accel * gb.power * torqueAt(this.rpm) * (ratio / gb.ratios[0]) * Math.min(1, grip + 0.15) * Math.min(1, throttle);
    } else if (throttle < 0) {
      target = -Math.min(topSpeed * c.reverseFactor, speedAtRpm(gb.redline, gb.reverseRatio));
      rate = clutchOpen ? 0 : c.accel * 0.6 * gb.power * Math.min(1, grip + 0.15) * Math.min(1, -throttle);
    }

    vF = approach(vF, target, rate * dt);
    if (brake > 0) vF = approach(vF, 0, c.brake * brake * Math.min(1, grip + 0.25) * dt);
    if (this.handbrake) vF = approach(vF, 0, c.handbrakeDecel * dt);

    // 5) Agarre lateral: a velocidade lateral decai. Menos agarre = escorrega mais.
    const k = c.lateralGrip * grip * (this.handbrake ? c.handbrakeSlip : 1);
    vL *= Math.exp(-k * dt);
    // Escorregar custa velocidade (arrasto de curva)
    vF = approach(vF, 0, Math.abs(vL) * c.slipDrag * dt);

    this.vx = fx * vF + rx * vL;
    this.vz = fz * vF + rz * vL;
    this.speed = vF;
    this.slip = vL;

    // 6) Movimento, com limite nas bordas do mapa
    let nx = this.x + this.vx * dt;
    let nz = this.z + this.vz * dt;
    // Borda do mapa: para só o movimento que sai do mapa e deixa deslizar ao longo dela
    const lim = t.half - 4;
    if (Math.abs(nx) > lim) {
      nx = Math.sign(nx) * lim;
      this.vx = 0;
    }
    if (Math.abs(nz) > lim) {
      nz = Math.sign(nz) * lim;
      this.vz = 0;
    }
    if (this.vx === 0 || this.vz === 0) this._syncAxes();
    this.x = nx;
    this.z = nz;

    // 7) Suspensão: quatro pontos medem o relevo; altura e inclinação vêm da média
    const wb = c.wheelBase / 2;
    const tr = c.track / 2;
    const hF = t.heightAt(this.x + fx * wb, this.z + fz * wb);
    const hB = t.heightAt(this.x - fx * wb, this.z - fz * wb);
    const hL = t.heightAt(this.x - rx * tr, this.z - rz * tr);
    const hR = t.heightAt(this.x + rx * tr, this.z + rz * tr);

    const targetY = (hF + hB + hL + hR) / 4 + c.lift;
    const maxDy = c.maxVerticalSpeed * dt; // limite de subida/descida: evita voo
    this.y += Math.max(-maxDy, Math.min(maxDy, targetY - this.y));

    this.slope = (hF - hB) / c.wheelBase;
    this.pitch = -Math.atan2(hF - hB, c.wheelBase);
    this.roll = Math.atan2(hR - hL, c.track);
  }

  // ---- Câmbio -------------------------------------------------------------

  // Relação total da marcha atual (ré usa a relação de ré)
  gearRatio() {
    const gb = CONFIG.gearbox;
    if (this.gear === -1) return gb.reverseRatio;
    return gb.ratios[Math.max(0, Math.min(gb.ratios.length - 1, this.gear - 1))];
  }

  // Troca de marcha: abre a embreagem e registra o evento para a partida
  _shiftTo(gear) {
    if (gear === this.gear) return false;
    const from = this.gear;
    this.gear = gear;
    this.shiftTimer = CONFIG.gearbox.shiftTime;
    this.gearShift = { from, to: gear, up: gear > from };
    return true;
  }

  _updateGearbox(dt, throttle) {
    const gb = CONFIG.gearbox;
    const absSpeed = Math.abs(this.speed);

    // Ré: entra ao pedir ré e sai quando o carro já está andando para frente
    if (throttle < -0.05) {
      if (this.gear !== -1) this._shiftTo(-1);
    } else if (this.gear === -1 && absSpeed < 1.2) {
      this._shiftTo(1);
    }

    const ratio = this.gearRatio();
    const wheelRpm = (absSpeed / (2 * Math.PI * gb.wheelRadius)) * 60;
    const rawRpm = wheelRpm * ratio * gb.finalDrive;

    // Embreagem patinando na largada: o motor sobe antes de a roda andar
    const launch = Math.max(0, throttle) * 1600 * Math.max(0, 1 - absSpeed / 8);
    const targetRpm = Math.max(gb.idleRpm, rawRpm + launch);
    this.rpm += (targetRpm - this.rpm) * Math.min(1, dt * 9);

    // Automático: decide pela fração da velocidade máxima da marcha.
    // Usar a fração (e não o RPM) faz a troca acontecer mesmo com acelerador parcial.
    if (this.autoShift && this.gear > 0) {
      const gearTop = speedAtRpm(gb.redline, ratio);
      const used = gearTop > 0.1 ? absSpeed / gearTop : 0;
      if (used > gb.upshiftAt && this.gear < gb.ratios.length) {
        this._shiftTo(this.gear + 1);
      } else if (used < gb.downshiftAt && this.gear > 1) {
        // Não desce se o motor fosse passar do redline na marcha de baixo
        const lowerTop = speedAtRpm(gb.redline, gb.ratios[this.gear - 2]);
        if (absSpeed < lowerTop * gb.upshiftAt) this._shiftTo(this.gear - 1);
      }
    }
  }

  // Troca manual (D-Pad). A primeira troca manual desliga o automático.
  shiftUp() {
    if (this.gear < 0) return false;
    if (this.gear >= CONFIG.gearbox.ratios.length) return false;
    this.autoShift = false;
    return this._shiftTo(this.gear + 1);
  }

  shiftDown() {
    if (this.gear > 1) {
      this.autoShift = false;
      return this._shiftTo(this.gear - 1);
    }
    if (this.gear === 1 && Math.abs(this.speed) < 0.8) {
      this.autoShift = false;
      return this._shiftTo(-1);
    }
    return false;
  }

  toggleAuto() {
    this.autoShift = !this.autoShift;
    return this.autoShift;
  }

  // ---- Faróis -------------------------------------------------------------

  // 0 desligado → 1 baixo → 2 alto → 0
  cycleLights() {
    this.lights = (this.lights + 1) % 3;
    return this.lights;
  }
}
