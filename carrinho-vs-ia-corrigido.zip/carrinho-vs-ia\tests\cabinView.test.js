// CabinView: exercita o desenho do overlay com um canvas 2D falso.
// Não valida pixels (impossível fora do navegador), mas garante que o caminho de
// desenho roda sem exceção — que é o tipo de erro que só aparecia no console.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CabinView } from '../src/render/cabinView.js';

function fakeCanvasContext() {
  const calls = { fillRect: 0, arc: 0, fill: 0, clearRect: 0 };
  const gradient = { addColorStop() {} };
  return {
    calls,
    fillStyle: null,
    globalCompositeOperation: 'source-over',
    clearRect() { calls.clearRect++; },
    createRadialGradient() { return gradient; },
    fillRect() { calls.fillRect++; },
    beginPath() {},
    arc() { calls.arc++; },
    fill() { calls.fill++; },
    moveTo() {},
    closePath() {},
  };
}

function fakeDocument() {
  const ctx = fakeCanvasContext();
  const canvas = {
    id: '',
    style: {},
    width: 0,
    height: 0,
    getContext: () => ctx,
  };
  return {
    ctx,
    canvas,
    body: { appendChild() {} },
    defaultView: { innerWidth: 1280, innerHeight: 720, addEventListener() {} },
    createElement: () => canvas,
  };
}

const cabinLike = (over = {}) => ({
  fog: 0,
  droplets: 0,
  wiperPhase: 0,
  wiperActive: false,
  ...over,
});

test('CabinView monta o canvas com metade da resolução', () => {
  const doc = fakeDocument();
  const view = new CabinView(doc);
  assert.equal(view.canvas.width, 640);
  assert.equal(view.canvas.height, 360);
});

test('CabinView não desenha nada com o vidro limpo', () => {
  const doc = fakeDocument();
  const view = new CabinView(doc);
  view.render(cabinLike());
  assert.equal(doc.canvas.style.opacity, '0');
  assert.equal(doc.ctx.calls.fillRect, 0);
});

test('CabinView desenha névoa e gotas quando embaçado', () => {
  const doc = fakeDocument();
  const view = new CabinView(doc);
  view.render(cabinLike({ fog: 0.6, droplets: 0.5 }));
  assert.equal(doc.canvas.style.opacity, '1');
  assert.ok(doc.ctx.calls.fillRect >= 1, 'devia pintar o véu');
  assert.ok(doc.ctx.calls.arc >= 10, 'devia desenhar gotas');
});

test('CabinView apaga o arco do limpador sem lançar erro', () => {
  const doc = fakeDocument();
  const view = new CabinView(doc);
  assert.doesNotThrow(() =>
    view.render(cabinLike({ fog: 0.3, droplets: 0.2, wiperActive: true, wiperPhase: 0.5 }))
  );
  assert.equal(doc.ctx.globalCompositeOperation, 'source-over', 'deve restaurar o modo de desenho');
});
