// Cabine: embaçamento do para-brisa e limpador.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CONFIG } from '../src/core/config.js';
import { Cabin } from '../src/gameplay/cabin.js';

const chuva = { id: 'chuva' };
const sol = { id: 'sol' };
const neblina = { id: 'neblina' };

const passos = (cabin, segundos, opts) => {
  for (let i = 0; i < Math.round(segundos * 60); i++) cabin.update(1 / 60, opts);
};

test('na chuva o vidro embaça com o tempo', () => {
  const c = new Cabin();
  assert.equal(c.fog, 0);
  passos(c, 3, { weather: chuva, speed: 10, wiperOn: false });
  assert.ok(c.fog > 0.05, `deveria embaçar, veio ${c.fog}`);
  assert.ok(c.droplets > 0);
});

test('no sol o vidro não embaça e seca', () => {
  const c = new Cabin();
  c.fog = 0.5;
  passos(c, 3, { weather: sol, speed: 10, wiperOn: false });
  assert.ok(c.fog < 0.5, 'deveria secar no sol');
  assert.equal(Cabin.isRainy(sol), false);
});

test('neblina também embaça', () => {
  assert.equal(Cabin.isRainy(neblina), true);
  const c = new Cabin();
  passos(c, 2, { weather: neblina, speed: 0, wiperOn: false });
  assert.ok(c.fog > 0);
});

test('o limpador limpa na chuva', () => {
  const c = new Cabin();
  passos(c, 4, { weather: chuva, speed: 10, wiperOn: false });
  const antes = c.fog;
  passos(c, 1.5, { weather: chuva, speed: 10, wiperOn: true });
  assert.ok(c.fog < antes, `limpador deveria reduzir a névoa (${antes} -> ${c.fog})`);
});

test('limpador a seco não limpa nada', () => {
  const c = new Cabin();
  c.fog = 0.4;
  passos(c, 2, { weather: sol, speed: 10, wiperOn: true });
  assert.ok(c.dryWiperTime > 0, 'deveria registrar limpador a seco');
  // No sol, a névoa só cai pela secagem natural (dryRate), nunca pela limpeza
  assert.ok(c.fog > 0, 'sem chuva o limpador não pode zerar a névoa');
});

test('o limpador conta varreduras (o "clac" do fim de curso)', () => {
  const c = new Cabin();
  let ticks = 0;
  const periodo = CONFIG.cabin.wiperPeriod;
  for (let i = 0; i < Math.round(periodo * 3.2 * 60); i++) {
    const r = c.update(1 / 60, { weather: chuva, speed: 5, wiperOn: true });
    if (r.tick) ticks++;
  }
  assert.ok(ticks >= 2, `esperava ao menos 2 inversões, veio ${ticks}`);
  assert.equal(c.wiperTicks, ticks);
});

test('a névoa fica sempre entre 0 e 1', () => {
  const c = new Cabin();
  passos(c, 60, { weather: chuva, speed: 30, wiperOn: false });
  assert.ok(c.fog <= 1 && c.fog >= 0);
  passos(c, 30, { weather: chuva, speed: 30, wiperOn: true });
  assert.ok(c.fog <= 1 && c.fog >= 0);
  passos(c, 60, { weather: sol, speed: 0, wiperOn: false });
  assert.ok(c.fog >= 0);
});

test('visibilidade é o complemento da névoa', () => {
  const c = new Cabin();
  c.fog = 0.25;
  assert.ok(Math.abs(c.visibility - 0.75) < 1e-9);
});

test('a névoa cresce mais rápido em alta velocidade', () => {
  const lento = new Cabin();
  const rapido = new Cabin();
  passos(lento, 1, { weather: chuva, speed: 0, wiperOn: false });
  passos(rapido, 1, { weather: chuva, speed: 26, wiperOn: false });
  assert.ok(rapido.fog > lento.fog);
});
