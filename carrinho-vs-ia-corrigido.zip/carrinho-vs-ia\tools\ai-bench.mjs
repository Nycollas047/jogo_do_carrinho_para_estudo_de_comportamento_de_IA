// Benchmark da IA: quanto ela coleta e quanto tempo fica presa.
//
// "Presa" = velocidade abaixo de 1 m/s com acelerador acima de 0,35 por mais de 0,5 s.
// Mede episódios, tempo total preso, tempo em água e distância percorrida.
//
// Uso: node tools/ai-bench.mjs [rodadas]
import { CONFIG } from '../src/core/config.js';
import { EventBus } from '../src/core/events.js';
import { createRng } from '../src/core/random.js';
import { Terrain } from '../src/world/terrain.js';
import { Props } from '../src/world/props.js';
import { CoinField } from '../src/world/coins.js';
import { Train } from '../src/world/train.js';
import { Vehicle } from '../src/vehicles/vehicle.js';
import { AIDriver } from '../src/vehicles/drivers.js';
import { Match } from '../src/gameplay/match.js';

const ROUNDS = Number(process.argv[2] ?? 4);

function build(round) {
  const terrain = new Terrain(CONFIG.seed);
  const props = new Props(terrain);
  props.generate(createRng(CONFIG.seed + 1));
  const coins = new CoinField(terrain, props);
  const train = new Train(terrain);
  const bus = new EventBus();
  const ref = { match: null };

  const player = new Vehicle({
    id: 'player',
    terrain,
    driver: { controls: () => ({ throttle: 0, brake: 0, steer: 0, handbrake: false }) },
  });
  const ai = new Vehicle({
    id: 'ai',
    terrain,
    driver: new AIDriver({
      terrain,
      props,
      getCoins: () => coins.coins,
      getHazards: () => ref.match.signals,
      getLead: () => 0,
    }),
  });
  const match = new Match({ bus, terrain, coins, props, train, player, ai });
  ref.match = match;
  match.round = round; // varia o sorteio sem mudar o mapa
  return { terrain, props, coins, train, bus, player, ai, match };
}

function run(round) {
  const { terrain, ai, match } = build(round);
  match.start();

  let stuckTime = 0;
  let stuckEpisodes = 0;
  let inEpisode = false;
  let waterTime = 0;
  let distance = 0;
  let lastX = ai.x;
  let lastZ = ai.z;

  const dt = 1 / 60;
  let steps = 0;
  while (match.state === 'playing') {
    match.update(dt);
    steps++;

    const moving = Math.abs(ai.speed) > 1;
    const wantsToMove = Math.abs(ai.controls?.throttle ?? 0) > 0.35;
    const stuckNow = !moving && wantsToMove;

    if (stuckNow) {
      stuckTime += dt;
      if (!inEpisode) {
        inEpisode = true;
        stuckEpisodes++;
      }
    } else {
      inEpisode = false;
    }

    if (ai.surface === 'agua') waterTime += dt;
    distance += Math.hypot(ai.x - lastX, ai.z - lastZ);
    lastX = ai.x;
    lastZ = ai.z;
  }

  return {
    rodada: round,
    moedasIA: match.scores.ai,
    presaEpisodios: stuckEpisodes,
    presaSegundos: +stuckTime.toFixed(1),
    aguaSegundos: +waterTime.toFixed(1),
    distancia: Math.round(distance),
    passos: steps,
  };
}

const rows = [];
for (let i = 1; i <= ROUNDS; i++) rows.push(run(i));

const sum = (k) => rows.reduce((s, r) => s + r[k], 0);
console.table(rows);
console.log(
  JSON.stringify(
    {
      rodadas: ROUNDS,
      moedasIA: sum('moedasIA'),
      mediaMoedas: +(sum('moedasIA') / ROUNDS).toFixed(2),
      presaEpisodios: sum('presaEpisodios'),
      presaSegundos: +sum('presaSegundos').toFixed(1),
      aguaSegundos: +sum('aguaSegundos').toFixed(1),
      distanciaMedia: Math.round(sum('distancia') / ROUNDS),
    },
    null,
    2
  )
);
