// Resolução de superfície: junta o perfil do piso com o clima.
// Um único lugar decide o que a superfície significa — física, háptica, HUD e som
// leem daqui em vez de repetir `if (surface === 'lama')` por todo lado.
import { SURFACES } from './config.js';

export const SURFACE_KEYS = Object.keys(SURFACES);

export const surfaceProfile = (key) => SURFACES[key] || SURFACES.asfalto;

// Pisos que passam a escorregar como gelo quando neva
const FREEZABLE = new Set(['asfalto', 'terra', 'grama', 'brita', 'areia']);

/**
 * Perfil efetivo do piso considerando o clima.
 * Devolve { key, label, grip, speedFactor, strong, weak, pulse, textureHz, grain,
 *           wet, frozen, aquaplane, color }
 */
export function effectiveSurface(key, weather) {
  const base = surfaceProfile(key);
  const id = weather?.id || 'sol';

  let profile = base;
  let label = base.label;
  let wet = false;
  let frozen = false;

  if (key !== 'agua' && key !== 'lama') {
    if (id === 'chuva') {
      wet = true;
      label = `${base.label} molhado`;
    } else if (id === 'neve' && FREEZABLE.has(key)) {
      // A neve cobre o piso: o que era aderente vira gelo
      frozen = true;
      profile = SURFACES.gelo;
      label = `Gelo sobre ${base.label.toLowerCase()}`;
    }
  }

  const grip = frozen ? SURFACES.gelo.grip : base.grip * (wet ? base.wetGrip : 1);
  const speedFactor = frozen ? SURFACES.gelo.speedFactor : base.speedFactor * (wet ? 0.97 : 1);

  return {
    key,
    label,
    grip,
    speedFactor,
    strong: profile.strong,
    // Piso molhado troca grave por agudo: some a textura, sobra o chiado
    weak: Math.min(1, profile.weak + (wet ? 0.10 : 0)),
    pulse: profile.pulse,
    textureHz: profile.textureHz,
    grain: profile.grain,
    wet,
    frozen,
    aquaplane: key === 'agua' ? 15 : Infinity,
    color: profile.color,
  };
}

// Quanto o piso "agarra" em 0..1, para escalar esforço do motor e do gatilho
export const gripRatio = (eff) => Math.max(0, Math.min(1, eff.grip));
