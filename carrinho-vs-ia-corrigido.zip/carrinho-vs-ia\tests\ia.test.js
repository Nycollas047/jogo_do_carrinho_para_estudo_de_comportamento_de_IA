// IA: saída da água e sanidade de uma partida inteira.
//
// Este arquivo também serve de trava contra "melhorias" que pioram a IA sem
// ninguém perceber. Para medir de verdade, use `npm run ia` (tools/ai-bench.mjs),
// que roda 8 partidas e compara moedas, tempo presa e distância.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CONFIG } from '../src/core/config.js';
import { EventBus } from '../src/core/events.js';
import { createRng } from '../src/core/random.js';
import { Terrain } from '../src/world/terrain.js';
import { Props } from '../src/world/props.js';
import { CoinField } from '../src/world/coins.js';
import { Train } from '../src/world/train.js';
import { Vehicle } from '../src/vehicles/vehicle.js';
import { AIDriver } from '../src/vehicles/drivers.js';
import { Match } from '../src/gameplay/match.js';

const terrain = new Terrain(CONFIG.seed);
const props = new Props(terrain);
props.generate(createRng(CONFIG.seed + 1));
const weather = { id: 'sol', grip: 1, hapticWeak: 0 };

// Ponto de água determinístico (nada de Math.random no teste)
function findWater() {
  for (let i = 0; i < 200; i++) {
    for (let j = 0; j < 200; j++) {
      const x = -terrain.half + 10 + i * 2.5;
      const z = -terrain.half + 10 + j * 2.5;
      if (terrain.surfaceAt(x, z) === 'agua') return { x, z };
    }
  }
  return null;
}

test('IA sai da água em direção à estrada', () => {
  const ponto = findWater();
  assert.ok(ponto, 'o mapa precisa ter água');

  const driver = new AIDriver({ terrain, props, getCoins: () => [] });
  const car = new Vehicle({ id: 'ai', terrain, driver });
  car.place(ponto.x, ponto.z, 0);
  // place() não calcula a superfície: o primeiro update é que lê o terreno
  car.update(1 / 60, weather);
  assert.equal(car.surface, 'agua', 'o carro deveria começar na água');

  let saiu = false;
  for (let i = 0; i < 60 * 12 && !saiu; i++) {
    car.update(1 / 60, weather);
    if (car.surface !== 'agua') saiu = true;
  }
  assert.ok(saiu, 'deveria sair da água em até 12 s');
});

test('IA coleta moedas e não passa a partida presa', () => {
  const bus = new EventBus();
  const coins = new CoinField(terrain, props);
  const train = new Train(terrain);
  const ref = { match: null };

  const player = new Vehicle({
    id: 'player',
    terrain,
    driver: { controls: () => ({ throttle: 0, brake: 0, steer: 0, handbrake: false }) },
  });
  const ai = new Vehicle({
    id: 'ai',
    terrain,
    driver: new AIDriver({
      terrain,
      props,
      getCoins: () => coins.coins,
      getHazards: () => ref.match.signals,
    }),
  });
  const match = new Match({ bus, terrain, coins, props, train, player, ai });
  ref.match = match;

  match.start();
  let presa = 0;
  let total = 0;
  const dt = 1 / 60;
  while (match.state === 'playing') {
    match.update(dt);
    total += dt;
    const querAndar = Math.abs(ai.controls?.throttle ?? 0) > 0.35;
    if (Math.abs(ai.speed) < 1 && querAndar) presa += dt;
  }

  assert.ok(match.scores.ai >= 5, `a IA deveria coletar moedas, coletou ${match.scores.ai}`);
  const fracao = presa / total;
  assert.ok(fracao < 0.25, `IA presa ${(fracao * 100).toFixed(1)}% da partida (limite 25%)`);
});

test('IA não escolhe moeda perto de cruzamento com trem fechado', () => {
  const coins = [
    { id: 1, x: 0, z: 0, value: 4 },
    { id: 2, x: 40, z: 0, value: 1 },
  ];
  const driver = new AIDriver({
    terrain,
    props: null,
    getCoins: () => coins,
    // cruzamento exatamente em cima da moeda 1
    getHazards: () => [{ x: 0, z: 0, state: 'red' }],
  });
  // Perto o bastante para as duas moedas entrarem no campo de visão (90 m)
  const car = { x: 40, z: 60, heading: 0, speed: 10, surface: 'asfalto' };
  const target = driver._target(car);
  assert.equal(target.id, 2, 'deveria ignorar a moeda em cima do cruzamento fechado');
});
