// Diagnóstico do caminho de entrada, sem navegador.
// Simula um DualSense no formato exato que o Chrome entrega (Gamepad API, mapping 'standard')
// e roda o pipeline real: Input → PlayerDriver → Vehicle.
//
// Objetivo: separar "bug de lógica de entrada" de "bug de detecção do dispositivo".

import { CONFIG } from '../src/core/config.js';
import { Terrain } from '../src/world/terrain.js';
import { Vehicle } from '../src/vehicles/vehicle.js';
import { PlayerDriver } from '../src/vehicles/drivers.js';
import { Input, readPad, readAllPads, setWebHidPadGetter } from '../src/input/input.js';

const weather = { grip: 1, hapticWeak: 0 };

// DualSense como o Chrome expõe via Gamepad API
function chromeDualSense({ lx = 0, ly = 0, rx = 0, ry = 0, r2 = 0, l2 = 0, held = [] } = {}) {
  const buttons = Array.from({ length: 17 }, () => ({ pressed: false, value: 0, touched: false }));
  buttons[6] = { pressed: l2 > 0, value: l2, touched: l2 > 0 };
  buttons[7] = { pressed: r2 > 0, value: r2, touched: r2 > 0 };
  for (const i of held) buttons[i] = { pressed: true, value: 1, touched: true };
  return {
    id: 'DualSense Wireless Controller (STANDARD GAMEPAD Vendor: 054c Product: 0ce6)',
    index: 0,
    connected: true,
    mapping: 'standard',
    timestamp: performance.now(),
    axes: [lx, ly, rx, ry],
    buttons,
    vibrationActuator: { type: 'dual-rumble' },
  };
}

function installFakeNavigator(pads) {
  Object.defineProperty(globalThis, 'navigator', {
    value: { getGamepads: () => pads, hid: undefined, userActivation: { hasBeenActive: true } },
    configurable: true,
    writable: true,
  });
}

const fakeWin = { addEventListener() {}, removeEventListener() {} };
const terrain = new Terrain(CONFIG.seed);

function driveLoop(label, { input, steps = 180, padAt = () => ({}) }) {
  const player = new Vehicle({ id: 'player', terrain, driver: new PlayerDriver(input) });
  player.place(terrain.roadPoint(0).x, terrain.roadPoint(0).z, 0);
  const readouts = [];
  for (let i = 0; i < steps; i++) {
    const pad = padAt(i);
    installFakeNavigator(pad ? [chromeDualSense(pad)] : []);
    player.update(1 / 60, weather);
    if (i % 30 === 0 || i === steps - 1) {
      readouts.push({ i, speed: +player.speed.toFixed(3), ...(player.controls ?? {}) });
    }
  }
  console.log(`\n### ${label}`);
  console.log('  controle (t)   :', readouts.map((r) => `t${r.i}:${r.throttle?.toFixed?.(2) ?? r.throttle}`).join(' '));
  console.log('  velocidade m/s :', readouts.map((r) => `t${r.i}:${r.speed}`).join(' '));
  console.log(`  >>> RESULTADO: velocidade final = ${player.speed.toFixed(3)} m/s ${Math.abs(player.speed) > 1 ? '(ANDA)' : '(PARADO)'}`);
  return player.speed;
}

console.log('=== 1. DualSense (Gamepad API, mapping standard) segurando R2 ===');
{
  const input = new Input(fakeWin);
  driveLoop('R2 = 1.0 constante', { input, padAt: () => ({ r2: 1 }) });
}

console.log('\n=== 2. DualSense com R2 em rampa (aperto progressivo) ===');
{
  const input = new Input(fakeWin);
  driveLoop('R2 0 → 1 em 1 s', { input, padAt: (i) => ({ r2: Math.min(1, i / 60) }) });
}

console.log('\n=== 3. DualSense empurrando o analógico esquerdo para frente ===');
{
  const input = new Input(fakeWin);
  driveLoop('stick Y = -1', { input, padAt: () => ({ ly: -1 }) });
}

console.log('\n=== 4. DualSense + WebHID conectado sem nenhum inputreport (estado nulo) ===');
{
  const input = new Input(fakeWin);
  const { parseDualSenseInputReport } = await import('../src/haptics/dualsense.js');
  // Payload USB 0x01 com R2 pressionado, no layout que o projeto assume
  const data = new Uint8Array(63);
  data[0] = 128; data[1] = 128; data[2] = 128; data[3] = 128;
  data[5] = 255; // R2
  const hidPad = parseDualSenseInputReport(0x01, new DataView(data.buffer), 'usb');
  setWebHidPadGetter(() => hidPad);
  console.log('  HID parseou:', hidPad ? `throttle=${readPad(hidPad).throttle.toFixed(2)}` : 'null');
  driveLoop('WebHID R2 = 255', { input, padAt: () => ({ r2: 1 }) });
  setWebHidPadGetter(null);
}

console.log('\n=== 5. DualSense USB: relatório com deslocamento de +1 byte (LX em data[1]) ===');
{
  const { parseDualSenseInputReport } = await import('../src/haptics/dualsense.js');
  const data = new Uint8Array(63);
  // Layout alternativo: data[0] = seq, LX em data[1]
  data[0] = 200;                 // seq
  data[1] = 128 + 128;           // LX ... mas clamp? usamos 255
  data[1] = 255; data[2] = 128;  // LX max direita
  data[3] = 128; data[4] = 128;
  data[6] = 255;                 // R2 neste outro layout
  const pad = parseDualSenseInputReport(0x01, new DataView(data.buffer), 'usb');
  const r = readPad(pad);
  console.log('  lido como:', { steer: +r.steer.toFixed(2), throttle: +r.throttle.toFixed(2), brake: +r.brake.toFixed(2) });
  console.log('  (se o layout real fosse deslocado, estes números denunciariam)');
}

console.log('\n=== 6. readAllPads com controle inativo (todos centrados) ===');
{
  installFakeNavigator([chromeDualSense({})]);
  console.log('  readAllPads:', JSON.stringify(readAllPads()));
}
