# Prompt do projeto — Carrinho vs IA

Cole o bloco abaixo como instrução inicial para outra IA (ou para você mesmo daqui a seis meses).
Ele descreve **o que o jogo é, como está organizado e o que não pode ser feito**, com os números
reais do código.

---

## PROMPT

Você vai trabalhar em **Carrinho vs IA**: um jogo de corrida de coleta de moedas contra uma IA,
em 3D low-poly, que roda no navegador **sem engine de jogo** — sem Unity, sem Unreal, sem Godot.
Tudo é JavaScript puro (ES modules) + Three.js apenas para desenhar.

### Restrições duras

1. **Sem engine e sem build step.** Nada de bundler, transpiler, TypeScript ou framework.
   Os arquivos são servidos como estão por um servidor HTTP estático (`node tools/serve.mjs`,
   porta 5173).
2. **Sem dependência de internet.** O Three.js vem de `node_modules/three/build/three.module.js`
   via `importmap` no `index.html`. Não troque por CDN por padrão.
3. **Nenhuma biblioteca de física, áudio ou UI.** Física, som (Web Audio) e HUD (DOM) são
   escritos à mão.
4. **As camadas de lógica não importam Three.js.** `core/`, `world/`, `vehicles/`, `gameplay/`
   são puros e rodam no Node. Só `render/` e `main.js` conhecem Three.js. Isso é o que permite
   testar o jogo sem navegador — se você quebrar essa regra, o projeto perde a testabilidade.
5. **Números de ajuste ficam em `src/core/config.js`.** Não espalhe constantes mágicas.

### Arquitetura em camadas

```
CAMADA 1: Regras      Match (tempo, placar, rodadas, penalidades, estados)
CAMADA 2: Simulação   Terrain ─ Vehicles ─ Train ─ Coins ─ Props
                      veículos recebem controles de um Driver
CAMADA 3: Apresentação HUD (DOM), háptica, câmera, render/* (Three.js), cabine (canvas 2D)
```

As camadas conversam por **contratos** e por um **EventBus**:

- `Driver.controls(vehicle, dt) → { throttle, brake, steer, handbrake }`
  Jogador e IA implementam a mesma interface; é o que permite trocar um pelo outro.
- Eventos: `coin:collected`, `vehicle:crash`, `vehicle:bump`, `vehicle:reset`,
  `vehicle:shift`, `vehicle:lights`, `match:start|pause|resume|end`, `weather:change`.

O perfil de cada superfície é **dado**, não `if`. Quem resolve piso + clima é
`core/surfaces.js` (`effectiveSurface`); física, háptica e HUD leem dali.

### Mundo e escala (1 unidade = 1 metro)

- Mapa 600 × 600 m, malha de 360 segmentos.
- Estrada em anel polar: raio 145 ± 20 m, meia-largura 3,8 m.
- Trilho em "8" que cruza a estrada 4 vezes: raio 165 ± 75 m, bitola real 1,435 m.
- Relevo por ruído (amplitude 27 m) + relevo suavizado por grade, para a pista não ficar íngreme.
- Terreno se molda à estrada e ao trilho nas margens (15 m e 12 m).
- Nível de água calculado **1,5 m abaixo do ponto mais baixo do leito da estrada** — a pista
  nunca alaga (há teste). As bacias enchem e formam lagoas; a beira vira areia.
- Carro 4,0 × 1,8 × 1,7 m; casa 6 m; pinheiro 6–10 m; locomotiva 16 m; vagão 12 m;
  trem a 20 m/s constantes, medidos por distância real sobre o trilho.

### Veículo e câmbio

- Movimento por vetor no mundo, decomposto em componente para frente e lateral; o lateral
  decai por agarre (é o que faz o carro escorregar na chuva, na lama e no gelo).
- Giro limitado por aceleração lateral máxima de 16 m/s² (~1,6 g): a taxa cai com a velocidade.
- Zona morta **radial** de 0,14, com reescala para 0..1; curva de direção com expoente 1,5.
- **Câmbio de 5 marchas + ré**: relações `[4.87, 3.74, 2.88, 2.21, 1.70]`, diferencial 5,2,
  raio de roda 0,33 m, marcha lenta 850 rpm, corte em 6800 rpm, embreagem de 0,18 s.
  RPM = velocidade da roda × relação × diferencial. O acelerador vira **força**, não teto de
  velocidade — senão a IA nunca chega ao ponto de troca. Troca automática por fração da faixa
  (88% sobe, 42% desce); a primeira troca manual assume o controle.
- Superfícies (9): asfalto, terra, grama, pedra, brita, lama, areia, água, gelo — cada uma com
  `grip`, `speedFactor`, `wetGrip`, cor, valor de moeda e **perfil tátil** (grave, agudo,
  frequência de textura, irregularidade). Chuva molha (grip × 0,62 no asfalto); neve congela
  asfalto/terra/grama em gelo (grip 0,18). Água acima de 15 m/s entra em aquaplanagem.

### Clima, cabine e faróis

- Cinco climas em ciclo por rodada: sol, chuva, neve, noite, neblina.
- **Chuva e neblina embaçam o para-brisa** ao longo do tempo (mais rápido em alta velocidade).
  O embaçamento é um overlay em canvas 2D sobre o WebGL; segurar **Círculo** liga o limpador,
  que apaga um arco do vidro a cada varredura. Fora da chuva o limpador não limpa — só range.
- **Faróis** (Triângulo, toque): desligado → baixo → alto. À noite/neblina/chuva o farol reduz
  a densidade da neblina na câmera: sem farol a visão encurta de verdade.

### Controles

| Ação | Controle PS5 | Teclado |
|---|---|---|
| Dirigir | analógico esquerdo | A/D ou setas |
| Acelerar | R2 | W/↑ |
| Frear; parado, ré | L2 | S/↓ |
| Freio de mão | Quadrado ou R1 | Espaço |
| Marcha ↑/↓ | D-Pad ↑/↓ | PageUp/PageDown |
| Automático ⇄ manual | L3 | — |
| Farol | Triângulo (toque) | L |
| Voltar à pista | Triângulo (segurar 0,6 s) | R |
| Limpador | Círculo (segurar) | V |
| Câmera / olhar atrás | analógico direito / R3 | Q/E, C |
| Pausa | Options | P ou Esc |
| Diagnóstico / teste de vibração | — | F2 / F3 |

O jogo pausa sozinho se a aba perde o foco. Botões de "toque × segurar" são resolvidos no
`Input` (um `_hold` com tempo), não no driver.

### Háptica (o coração do projeto)

O controle é um **instrumento de informação**, não um vibrador genérico. Canais:

| Canal | Motor | Prioridade |
|---|---|---|
| Evento (batida, trem, moeda, tranco de marcha, clique do farol) | grave + agudo | vence por N ms |
| Superfície | grave/agudo | contínuo, 12 Hz |
| Motor / RPM | grave = carga, agudo = rotação | contínuo |
| Limpador | agudo, no ritmo da varredura | enquanto ativo |
| Aviso de trem | grave rítmico que acelera ao aproximar | enquanto perto |

- Gatilhos adaptáveis: R2 com resistência por carga de marcha/superfície (pedal pesado em
  marcha baixa, leve em marcha alta, mole no gelo); L2 com ABS pulsante e estalo na ré.
- 5 LEDs = **barra de RPM**; lightbar = cor da superfície, vermelha com trem, azul com limpador.
- DualSense via WebHID: relatório USB 0x02 (47 bytes) e Bluetooth 0x31 (77 bytes, CRC32).
  Escolha a coleção HID de **gamepad (usage 0x05)**, nunca a do mouse (0x04).
- Se o navegador entregar o controle sem mapeamento "standard", leia os gatilhos pelos eixos
  3/4, com o repouso **calibrado** (só usa o eixo depois de vê-lo em -1).
- Sempre haja diagnóstico: painel F2 mostra entrada (fontes, quem está mudo há quanto tempo),
  veículo (marcha, RPM, piso efetivo, profundidade da água) e cabine (névoa, limpador).

### IA

Persegue a melhor moeda por valor/distância (nota `valor / (distância + 12)`), desvia de
obstáculos por repulsão local, freia em cruzamento com sinal fechado, sai da água em direção à
estrada e se recupera de enrosco (ré cada vez mais longa, abandona a moeda). Tem "elástico":
perde rendimento quando está na frente, ganha quando está atrás. Dificuldades: fácil 0,7,
normal 0,85, difícil 1,0.

**Não implemente A\* nem navmesh sem medir**: essa tentativa foi feita e perdeu para o desvio
local (22,5 e 16,6 moedas contra 27,0). O banco de medição é `npm run ia`.

### Testes e critérios de aceitação

- `npm test` roda **103 testes** em Node, sem navegador, mais um smoke test das malhas visuais.
- Cobertura mínima obrigatória: relevo reproduzível, inclinação de pista e trilho, nível de água
  abaixo da estrada, moedas/obstáculos fora da água, câmbio (relações, torque, trocas, ré,
  embreagem), perfis de superfície e efeito do clima, névoa/limpador, mapeamento de controle
  (incluindo gatilhos por eixo), háptica (CRC, relatórios, gatilhos, LEDs), IA (níveis, sinal,
  água, não passar de 25% do tempo presa), e uma trava estática de imports.
- Qualquer exceção dentro do loop de animação mata o jogo inteiro (o `requestAnimationFrame`
  fica no fim do quadro). Por isso existe `tests/imports.test.js`: falha se um módulo usar
  `CONFIG`, `SURFACES`, `WEATHER`, `EventBus`, `createRng` ou `THREE` sem importar.
- Nunca altere um teste para "passar": se o comportamento mudou por decisão de design, atualize
  o teste **e** documente a mudança de contrato.

### Como verificar

```bash
npm start        # http://localhost:5173
npm test         # 103 testes + smoke visual
npm run diag     # diagnóstico do input com DualSense simulado
npm run ia       # 8 partidas: moedas, tempo presa, distância
npm run analise  # mede o mapa e escreve docs/analise-mapa.json
```

No Windows, se o `npm` estiver bloqueado pela política do PowerShell, rode
`node tools/serve.mjs` e `node --test tests/*.test.js`.

### Estilo de trabalho esperado

- Mudança pequena, teste verde, próxima mudança. Não refatore e adicione feature no mesmo passo.
- Quando um número muda o "feel" (força do motor, aderência, intensidade háptica), diga onde ele
  fica e qual era o valor anterior.
- Se uma ideia não puder ser medida, não a apresente como melhoria — apresente como hipótese.
- Visual e háptica em hardware real só o dono do controle pode validar: peça confirmação em vez
  de afirmar que funciona.

---

## Versão curta (para colar em um chat)

> Trabalhe em **Carrinho vs IA**: corrida 3D low-poly de coletar moedas contra uma IA, no
> navegador, **sem engine** — JavaScript puro com ES modules e Three.js só para desenhar
> (carregado de `node_modules` via importmap, sem CDN, sem bundler, sem build).
>
> Arquitetura em camadas: `core/` (config, superfícies, eventos), `world/` (terreno, trilho,
> trem, moedas, obstáculos), `vehicles/` (física + câmbio + drivers), `gameplay/` (partida,
> cabine), `input/`, `haptics/`, `ui/`, `render/` (só Three.js). **As quatro primeiras não podem
> importar Three.js** — é o que permite testar tudo no Node. Camadas conversam por contratos
> (`Driver.controls(vehicle, dt) → {throttle, brake, steer, handbrake}`) e por eventos
> (`coin:collected`, `vehicle:shift`, ...).
>
> Mundo 600 × 600 m, 1 unidade = 1 metro. Estrada em anel (raio 145 ± 20), trilho em "8" que
> cruza a pista 4 vezes, trem a 20 m/s. Nível de água 1,5 m abaixo do ponto mais baixo da
> estrada: as bacias viram lagoas e a pista nunca alaga. Nove superfícies (asfalto, terra, grama,
> pedra, brita, lama, areia, água, gelo) com agarre, velocidade e **perfil tátil** próprios;
> chuva molha, neve congela. Um único módulo resolve piso + clima — não escreva `if (piso === ...)`
> espalhado.
>
> Carro com câmbio de 5 marchas + ré (relações `[4.87, 3.74, 2.88, 2.21, 1.70]`, diferencial 5,2,
> corte 6800 rpm, embreagem 0,18 s), RPM derivado da velocidade, troca automática por fração da
> faixa e manual no D-Pad. Acelerador é força, não teto de velocidade.
>
> Controles: R2 acelera, L2 freia/ré, Quadrado/R1 freio de mão, D-Pad ↑/↓ marcha, L3
> auto/manual, **Triângulo = farol no toque e voltar à pista segurando 0,6 s**, **Círculo =
> limpador** (só funciona na chuva, quando o vidro embaça num overlay 2D), analógico direito
> câmera, R3 olha para trás.
>
> O controle é instrumento de informação: grave = carga/superfície, agudo = textura/derrapagem,
> 5 LEDs = barra de RPM, lightbar = superfície/clima, gatilhos adaptáveis com resistência por
> carga e ABS. DualSense por WebHID (USB 0x02, BT 0x31 com CRC32), escolhendo a coleção de
> gamepad (usage 0x05). Sempre com diagnóstico: F2 mostra entrada, veículo e cabine.
>
> Regras de trabalho: números de ajuste só em `src/core/config.js`; mudança pequena com teste
> verde; **nunca** altere teste para passar (se o contrato mudou, atualize e documente); qualquer
> exceção no loop mata o jogo, então toda dependência precisa de import explícito; melhoria sem
> medição é hipótese, não fato. Verificação: `npm start`, `npm test` (103 testes), `npm run diag`,
> `npm run ia`.

