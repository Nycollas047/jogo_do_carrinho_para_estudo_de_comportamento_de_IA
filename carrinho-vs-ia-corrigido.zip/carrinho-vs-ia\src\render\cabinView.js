// Overlay da cabine: desenha embaçamento, gotas e o arco do limpador.
// Fica em um canvas 2D sobre o WebGL (não toca no render 3D) e só desenha
// quando há algo para mostrar — fora da chuva o custo é zero.
export class CabinView {
  constructor(doc = document) {
    this.doc = doc;
    const canvas = doc.createElement('canvas');
    canvas.id = 'cabin-view';
    Object.assign(canvas.style, {
      position: 'fixed',
      inset: '0',
      width: '100%',
      height: '100%',
      pointerEvents: 'none',
      zIndex: '2',
      opacity: '0',
      transition: 'opacity .2s',
    });
    doc.body.appendChild(canvas);
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.drops = [];
    this.resize();
    doc.defaultView?.addEventListener?.('resize', () => this.resize());
  }

  resize() {
    const w = this.doc.defaultView?.innerWidth || 1280;
    const h = this.doc.defaultView?.innerHeight || 720;
    // Metade da resolução: suficiente para névoa e gotas, e barato
    this.canvas.width = Math.max(1, Math.round(w / 2));
    this.canvas.height = Math.max(1, Math.round(h / 2));
    if (this.drops.length === 0) {
      for (let i = 0; i < 150; i++) {
        this.drops.push({
          x: Math.random(),
          y: Math.random(),
          r: 0.6 + Math.random() * 2.4,
          s: 0.3 + Math.random(),
        });
      }
    }
  }

  render(cabin) {
    const fog = cabin.fog;
    if (fog < 0.01 && cabin.droplets < 0.01) {
      this.canvas.style.opacity = '0';
      return;
    }
    this.canvas.style.opacity = '1';

    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Véu de embaçamento: mais forte nas bordas (vidro suado)
    const g = ctx.createRadialGradient(
      w / 2,
      h * 0.55,
      Math.min(w, h) * 0.18,
      w / 2,
      h / 2,
      Math.max(w, h) * 0.75
    );
    g.addColorStop(0, `rgba(226,236,244,${0.10 * fog})`);
    g.addColorStop(0.55, `rgba(214,226,238,${0.38 * fog})`);
    g.addColorStop(1, `rgba(198,212,226,${0.72 * fog})`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);

    // Gotas
    if (cabin.droplets > 0.02) {
      ctx.fillStyle = `rgba(210,230,255,${0.35 * cabin.droplets})`;
      for (const d of this.drops) {
        ctx.beginPath();
        ctx.arc(d.x * w, d.y * h, d.r * d.s, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Limpador: apaga um arco do vidro (destination-out)
    if (cabin.wiperActive) {
      const px = w * 0.5;
      const py = h * 1.02;
      const radius = Math.hypot(w, h) * 1.1;
      const a = -Math.PI * 0.78 + Math.PI * 0.56 * cabin.wiperPhase;
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.moveTo(px, py);
      ctx.arc(px, py, radius, a - 0.1, a + 0.1);
      ctx.closePath();
      ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
    }
  }
}
