# Plano de melhorias — cenário, direção e feedback tátil

> Estado de partida: 65 testes verdes, jogo rodando em `http://localhost:5173`.
> Objetivo: transformar o controle em **instrumento de informação** (o que o carro está pisando,
> em que marcha está, o que o cenário avisa), e não só em vibração genérica.

---

## 0. O problema de arquitetura que precisa ser resolvido antes

Hoje o comportamento de uma superfície está espalhado em **ifs duplicados**:

| Arquivo | O que faz com a superfície |
|---|---|
| `world/terrain.js` | decide qual superfície é (`surfaceAt`) com limiares soltos |
| `core/config.js` | define atrito, cor, valor da moeda, vibração |
| `haptics/haptics.js` | cadeia `if (surfaceKey === 'lama') ... else if ('terra') ...` |
| `render/terrainView.js` | cor por vértice |
| `vehicles/vehicle.js` | física (grip/speedFactor) |

Adicionar "água" do jeito atual exigiria mexer em 5 arquivos e lembrar de todos. A primeira
fase do plano é **inverter isso**: superfície vira um *perfil de dados*, e todo o resto lê o perfil.
Sem essa base, cada novo relevo é uma dívida nova.

---

## A. Relevos e superfícies (o pedido central)

### A.1 Perfil de superfície (novo formato em `core/config.js`)

```js
asfalto: {
  label: 'Asfalto', color: 0x3a3d44, coinValue: 1,
  grip: 1.00, speedFactor: 1.00, drag: 0,
  wetGrip: 0.62,            // multiplicador quando molhado
  haptic: { strong: 0.05, weak: 0.14, textureHz: 0, grain: 0.0, pulse: false },
  fx: { particles: 'dust', sound: 'asphalt' },
}
```

`haptic` substitui a cadeia de ifs. Todos os consumidores passam a ler o perfil.

### A.2 Superfícies atuais + novas

| Superfície | Gripe | Vel. | Feedback tátil (grave/agudo) | Leitura de jogo |
|---|---:|---:|---|---|
| `asfalto` | 1,00 | 1,00 | 0,05 / 0,14 — zumbido fino | referência rápida |
| `asfalto_molhado` (mod) | 0,62 | 0,96 | agudo sobe + chiado contínuo | freia antes, escorrega |
| `terra` | 0,80 | 0,80 | 0,22 / 0,28 — cascalho irregular | médio |
| `grama` | 0,75 | 0,70 | 0,08 / 0,18 — aveludado | estável, lento |
| `pedra` | 0,70 | 0,60 | 0,55 / 0,40 — impactos secos (pulso) | quebra o carro |
| `brita` (novo) | 0,55 | 0,65 | 0,45 / 0,50 — tremor solto e rápido | instável, perto do trem |
| `lama` | 0,45 | 0,40 | 0,30 / 0,50 — sucção em 4 Hz (pulso) | gruda, exige ré |
| `areia` (novo) | 0,42 | 0,50 | 0,25 / 0,35 — deslizamento contínuo | afunda, perde velocidade |
| `agua` (novo) | 0,30 | 0,35 | 0,35 / 0,65 — assobio agudo + estouro ao entrar | aquaplanagem acima de 15 m/s |
| `gelo` (novo, neve) | 0,18 | 0,85 | 0,02 / 0,30 — quase nenhuma textura | direção quase decorativa |

**Por que isso melhora a informação:** cada superfície ganha uma *assinatura* distinguível
(gravidade, frequência e regularidade), então o jogador **sente** onde está antes de olhar o HUD.
`agua` e `gelo` são deliberadamente "lisos" — a ausência de textura é a informação.

### A.3 Água no mapa (o pedido "água")

- `CONFIG.water = { level: <calculado>, depth: 1.2 }`.
- `level` é derivado: `min(altura do leito da estrada) − 1,5 m`, calculado uma vez no `Terrain`.
  Assim a pista nunca alaga — garantido por teste.
- `terrain.surfaceAt()`: se `rawHeight < level` e longe de estrada/trilho → `agua`.
- Render: plano translúcido único em `y = level` (o terreno acima oculta, as bacias enchem).
- `agua` rasa (< 0,4 m) = `agua_rasa`: atravessável, respinga; profunda = arrasto forte.
- Partículas de respingo e som de água ao entrar/sair.
- **Restrições de mundo:** árvores, casas, pedras e moedas não nascem em água (`props.js`,
  `coins.js`). A IA evita água profunda (trata como obstáculo no `_avoid`).

### A.4 Molhabilidade dinâmica (chuva/neve mudam o chão)

Em vez de duplicar superfícies, um modificador:

```js
effective(surface, weather) → { grip, speedFactor, hapticScale }
```

- `chuva`: grip × 0,62; asfalto/terra/grama viram "molhados" (mais agudo, menos grave).
- `neve`: grip × 0,45 no asfalto; grama/terra viram `gelo` (tato quase ausente).
- `lama` já é lama; chuva a deixa pior.

Isso conecta o clima que **já existe** ao tato, sem inflar a tabela.

---

## B. Sistema de marchas

### B.1 Física (`vehicles/vehicle.js` + `core/config.js`)

```js
CONFIG.gearbox = {
  ratios: [3.55, 2.45, 1.85, 1.45, 1.15], // 1ª → 5ª
  finalDrive: 3.9, wheelRadius: 0.33,
  idleRpm: 850, redline: 6800,
  shiftUpRpm: 6200, shiftDownRpm: 2600,
  shiftTime: 0.18,          // embreagem: torque cortado
  reverseRatio: 3.2,
  torqueCurve: [[800,0.55],[2000,0.85],[4200,1.0],[5800,0.82],[6800,0.55]],
};
```

- `rpm = velocidadeDaRoda × ratio × finalDrive` (marcha ré = ratio negativo).
- Força = `torque(rpm) × ratio × finalDrive / raio`.
- Acima do redline: corte de torque (o carro "encosta").
- `shiftTime` corta o torque por 0,18 s — e **é justamente aí que entra o feedback** (tranco curto).
- Auto e manual compartilhados: manual apenas troca antes do automático decidir.

### B.2 Controles

| Ação | Antes | Depois |
|---|---|---|
| Acelerar | R2 ou Cruz | R2 (analógico) · Cruz segue como alternativa digital |
| Frear / ré | L2, Círculo, D-Pad ↓ | **L2** (Círculo e D-Pad ↓ liberados) |
| Freio de mão | Quadrado, R1, L1 | **Quadrado** e **R1** |
| Voltar à pista | Triângulo | **segurar Triângulo 0,6 s** (mantém custo de 1 moeda) |
| Farol | — | **Triângulo (toque)** — ver C |
| Limpador | — | **Círculo (segurar)** — ver D |
| Marcha ↑ / ↓ | — | **D-Pad ↑ / ↓** |
| Auto ⇄ manual | — | **L3** (clique do analógico esquerdo) |
| Câmera / olhar atrás | analógico direito / R3 | igual |
| L1 | freio de mão | **livre** (reserva para 4×4 ou boost) |

### B.3 O que a marcha informa no controle

| Canal | Informação |
|---|---|
| Motor grave (strong) | carga do motor: forte em marcha baixa com acelerador, some em alta |
| Motor agudo (weak) | rotação: sobe com o RPM, vira assobio perto do redline |
| 5 LEDs | **barra de RPM** (substitui a barra de velocidade — mais útil, o velocímetro já está no HUD) |
| R2 | resistência sobe com carga e cai em marcha alta (motor "solto") |
| Pulso curto no tranco | troca de marcha (só na troca, nunca no contínuo) |
| Rajada no redline | aviso de corte de giro |

HUD ganha `N R 1 2 3 4 5` + barra de RPM; o som usa o RPM real em vez de `Math.floor(speed/7.5)`.

---

## C. Faróis no Triângulo

- Estados: `off → baixo → alto → off` (toque) — `vehicle.lights`.
- **Visual:** dois `SpotLight` presos ao carro + material emissivo nos faróis + feixe visível
  na chuva/neblina (cone translúcido).
- **Jogo:** à noite e na neblina, o farol aumenta o alcance da seta de moeda e a distinção de
  obstáculos na pista. Sem farol, visão curta — decisão real, não cosmético.
- **Feedback:** clique curto (weak 0,35 / 60 ms) ao trocar; LED 5 pisca uma vez; a lightbar
  ganha um tom frio quando o alto está ligado.
- **Custo:** energia não é simulada; a troca é livre (evita frustração no protótipo).

---

## D. Limpador (Círculo) + embaçamento do para-brisa

### D.1 Estado (módulo novo `gameplay/cabin.js`)

```js
cabin = { fog: 0..1, droplets: 0..1, wiper: { active, phase, speed } }
```

- `fog` cresce **só na chuva** (e devagar em neblina), proporcional ao tempo e à velocidade.
- Limpador ativo: `fog` e `droplets` caem por varredura completa; sem limpador, `fog` chega a 1.
- Fora de chuva: ligar o limpador **não faz nada** além de um rangido a seco (sem háptica).

### D.2 Efeito na tela (o "embaçado" que o jogador vê)

- Overlay em canvas 2D sobre o WebGL (`#cabin`), sem tocar no render.
- `fog` controla opacidade + desfoque radial nas bordas (efeito de vidro suado).
- Gotas desenhadas proceduralmente; o **arco do limpador apaga** a região varrida.
- Se `fog → 1`, a visão fica realmente ruim (é a consequência de ignorar o limpador).
- Só existe visual quando há chuva/neblina; nos outros climas o overlay fica desligado.

### D.3 Feedback

- Varredura = pulso ritmado no motor agudo (frequência = velocidade do limpador).
- Inversão de curso = tick curto (o "clac" das escovas).
- Custo de atenção: o limpador ocupa o motor agudo por ~0,6 s — informação tátil **disputa**
  espaço com a textura do piso. É por isso que o mixer da Parte E é obrigatório.

---

## E. Mixer háptico (o coração do "feedback passa informação")

Hoje cada sistema escreve direto no controle e o último vence. Com marcha + farol + limpador +
água, isso vira lama tátil. Proposta:

### E.1 Canais

| Canal | Motor | Prioridade | Janela |
|---|---|---|---|
| Evento (batida, trem, moeda, tranco) | strong+weak | 100 | sobrepõe por N ms |
| Superfície | strong/weak | 40 | contínuo, 12 Hz |
| Motor / RPM | strong/weak | 50 | contínuo |
| Limpador | weak | 60 (enquanto ativo) | 0,6 s por varredura |
| Aviso de trem | strong rítmico | 80 | enquanto `trainNear > 0` |
| Gatilhos R2/L2 | atuadores | — | contínuo |

Regra de mistura: **prioridade manda no motor; o contínuo nunca zera um evento.** Depois de um
evento, o canal de superfície volta com rampa de 120 ms (evita "salto" no tato).

### E.2 O que cada peça do cenário informa

| Elemento do mapa | Como o jogador sente |
|---|---|
| Asfalto seco | zumbido fino de rolamento |
| Asfalto molhado | chiado agudo + perda de firmeza no R2 |
| Brita do trilho | tremor solto e irregular |
| Trem próximo | batida grave rítmica que acelera |
| Lama | sucção em 4 Hz + engasgo nas trocas |
| Água | assobio agudo (aquaplanagem) + estouro na entrada |
| Gelo/neve | quase silêncio tátil = perigo |
| Marcha errada | motor "pesado" (vibração de baixa) ou gritando no corte |
| Limpador | varredura rítmica |

---

## F. HUD e diagnóstico

- HUD: marcha, RPM, farol, limpador, superfície, "embaçado: X%".
- F2 ganha duas seções novas: `VEÍCULO` (marcha, RPM, carga, gelo/água) e `CABINE`
  (névoa, limpador, farol), além do `ENTRADA` já existente.
- Toda grandeza que afeta o tato aparece no painel — se não dá para ver, não dá para depurar.

---

## G. Testes (o plano só fecha com eles)

Novos, em arquivos separados por domínio:

| Arquivo | Cobre |
|---|---|
| `tests/marchas.test.js` | ratios monotônicos, RPM = f(velocidade, marcha), auto sobe/desce nos limiares, corte no redline, ré, `shiftTime` sem NaN |
| `tests/superficies.test.js` | todo `surfaceAt` devolve superfície existente; água só abaixo do nível; nível abaixo do leito da estrada; nenhuma moeda/árvore em água; modificador de chuva/neve reduz grip |
| `tests/cabine.test.js` | névoa cresce só na chuva; limpador limpa; limpador a seco é inócuo; `fog` nunca sai de 0..1 |
| `tests/farol.test.js` | ciclo off→baixo→alto→off; alcance de visão muda; só afeta apresentação |
| `tests/mixer.test.js` | prioridade: evento vence contínuo; contínuo não zera evento; todos os valores 0..1; sem NaN em 210 s |
| `tests/entrada.test.js` | novos botões: Triângulo toque × segurar, Círculo, D-Pad como marcha |

Meta: **~95 testes**, mantendo os 65 atuais verdes. Mais um teste de simulação longa
(210 s) garantindo que nada estoura com os sistemas novos.

---

## H. Fases de execução

| # | Fase | Entrega | Tamanho |
|---|---|---|---|
| 0 | Perfil de superfície | `SURFACES` com `haptic`/`wetGrip`; `haptics.js` sem ifs; testes | M |
| 1 | Marchas | física, D-Pad, HUD, som, LEDs, tranco | G |
| 2 | Faróis | estados, luzes, alcance, feedback | M |
| 3 | Cabine | névoa, limpador, overlay canvas, feedback | G |
| 4 | Água + relevos novos | nível de água, brita, areia, gelo, restrições de mundo | G |
| 5 | Mixer | canais, prioridade, rampas | M |
| 6 | HUD/F2 + polimento | painéis, partículas, sons | M |

Ordem escolhida para que **cada fase termine jogável e testada**. Mixer vem depois dos
sistemas porque precisa saber o que misturar; água vem depois das marchas porque a marcha
muda como o carro reage a ela.

---

## I. Riscos conhecidos

1. **Excesso de tato.** Com 5 canais, tudo vira ruído. Mitigação: mixer com prioridade + teto
   de intensidade + teste de "um evento por vez".
2. **Água alagando a pista.** Mitigação: nível derivado do leito da estrada + teste.
3. **Conflito de botões.** Triângulo e Círculo já têm função. Mitigação: toque × segurar, e o
   reset muda para "segurar" (documentado no HUD e no README).
4. **Custo do overlay de névoa.** Canvas 2D em tela cheia pode custar. Mitigação: resolução
   reduzida do canvas e só desenhar quando `fog > 0.01`.
5. **IA em água/brita.** A IA não conhece os relevos novos. Mitigação: tratar água profunda
   como obstáculo e reduzir a velocidade-alvo em brita.

---

## J. Decisões que precisam do seu aval

1. **Mapa de botões** da seção B.2 — em especial: Triângulo (toque = farol, segurar = voltar à
   pista) e D-Pad ↑/↓ como marcha. Confirma?
2. **Água:** poças rasas + riacho/lago (com nível global no mapa), ou só poças?
3. **Marcha:** começa em **automática** (troca sozinha, e o D-Pad assume quando você quiser) ou
   **manual pura** desde o início?
4. **Prioridade de escopo:** se for para entregar em etapas, sugiro **Fase 0 + 1 + 5** primeiro
   (base de dados, marchas e mixer) — é o que mais muda a sensação de direção. Água e limpador
   depois.

---

## K. Status da implementação (atualizado)

Todas as fases A–G foram implementadas nesta mesma sessão. Decisões tomadas pelo caminho:

| Tema | Decisão aplicada |
|---|---|
| Mapa de botões | Triângulo toque = farol, segurar 0,6 s = voltar à pista; Círculo = limpador; D-Pad ↑/↓ = marcha; L3 = auto/manual; L1 livre |
| Água | Nível global derivado do leito da estrada (1,5 m abaixo do mínimo) — lagoas + praia de areia |
| Marcha | Começa automática; a primeira troca manual assume (L3 devolve o automático) |
| Torque | Acelerador virou **força**, não teto de velocidade; a troca usa fração da faixa |
| Água na IA | A IA sai da água em direção à estrada em vez de perseguir moeda |

Resultado: **103 testes, 0 falhas** (eram 65). Os 38 novos cobrem marchas, superfícies, cabine,
o desenho do overlay e a IA.

### K.1 Experimento de navegação da IA (rejeitado por medição)

Foi implementada uma grade de passabilidade + A* (`navgrid.js`) com três variantes, e medido
com `tools/ai-bench.mjs` (8 partidas de 210 s, mesmo mapa, sementes de moeda diferentes):

| Variante | Moedas | Episódios presa | Segundos presa |
|---|---:|---:|---:|
| IA original | **27,00** | 148 | **82,3** |
| + desvio por A* | 22,50 | 160 | 83,4 |
| + A* e volta para a estrada | 16,63 | 156 | 93,6 |

O A* perdeu em todas as configurações: caminho mais longo, menos distância percorrida, menos
moedas. **Decisão:** remover o código (em vez de deixá-lo desligado) e manter o banco de medição.
O que sobrou de ganho real da IA foi a saída da água, que é consequência do mapa novo e está
coberta por teste.

Pendências conhecidas (não bloqueiam o jogo):

- `tests/mixer.test.js` não foi criado como arquivo separado: a mistura está coberta
  indiretamente pelos testes de háptica existentes (prioridade por `effectUntil`) e pelos
  testes de cabine/marcha que alimentam o mixer.
- A validação visual em hardware (DualSense real) continua pendente — depende de você.
- A IA ainda fica presa ~5% da partida. Não é um bug conhecido: é o limite do desvio local,
  e a alternativa testada (A*) foi pior.

