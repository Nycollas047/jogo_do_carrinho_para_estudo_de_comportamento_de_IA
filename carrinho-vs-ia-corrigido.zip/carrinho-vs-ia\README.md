# Carrinho vs IA

Corrida de coleta de moedas contra uma IA. Three.js, visual low-poly, controle PS5 com vibração.

## Como rodar

ES modules não funcionam abrindo o `index.html` direto do disco. Use um servidor local:

```bash
npm start          # servidor nativo do projeto, sem dependências
# abra http://localhost:5173
```

Se o `npm` estiver bloqueado pela política do PowerShell no Windows, rode `node tools/serve.mjs`.

Use Chrome ou Edge em `http://localhost` ou HTTPS. Para vibração WebHID, conecte o DualSense por cabo USB.

O Three.js é carregado do próprio projeto (`node_modules/three/build/three.module.js`), então **o jogo funciona sem internet**. Se quiser usar CDN, o importmap no `index.html` tem a linha comentada.

## Controles

| Ação | Controle PS5 | Teclado |
|---|---|---|
| Dirigir | Analógico esquerdo | A / D ou setas |
| Acelerar | R2 | W / ↑ |
| Frear; parado, dar ré | L2 | S / ↓ |
| Freio de mão (derrapar) | Quadrado ou R1 | Espaço |
| Trocar de marcha (↑ sobe, ↓ desce) | D-Pad ↑ / ↓ | PageUp / PageDown |
| Automático ⇄ manual | L3 (clique do analógico esquerdo) | — |
| Farol (desligado → baixo → alto) | **Triângulo (toque)** | L |
| Voltar à pista (custa 1 moeda, espera 3 s) | **Triângulo (segurar 0,6 s)** | R |
| Limpador de para-brisa (segurar, na chuva) | **Círculo** | V |
| Girar a câmera | Analógico direito | Q / E |
| Olhar para trás | R3 | C |
| Pausar / continuar; começar / reiniciar | Options | P ou Esc / Enter |
| Painel de diagnóstico / vibração de teste | — | F2 / F3 |

O jogo pausa sozinho se você trocar de aba.

### Mudanças de botão (importante)

- O **Triângulo** era "voltar à pista" e agora é **farol no toque**. Segurar 0,6 s continua voltando à pista.
- O **Círculo** deixou de frear (o L2 faz isso) e virou **limpador**.
- O **D-Pad ↑/↓** deixou de acelerar/frear e virou **marcha**. O acelerador digital segue no Cruz.
- **L1** ficou livre.

### Marchas

5 marchas + ré, com curva de torque, redline e **embreagem de 0,18 s** — o corte de força na troca
é o tranco que o controle sente. Começa **automático**: a primeira vez que você usa o D-Pad, o
câmbio passa a ser manual (L3 alterna de volta).

O RPM é derivado da velocidade e da relação da marcha, então o mesmo piso dá RPM diferente em
marchas diferentes. Quem usa isso: HUD (marcha + RPM), som do motor, **barra de RPM nos 5 LEDs**
do DualSense e o r2 háptico (resistência do pedal).

### Água, praia e brita

O mapa ganhou um **nível de água** calculado 1,5 m abaixo do ponto mais baixo do leito da estrada —
por construção, a pista nunca alaga (há teste para isso). As bacias do relevo enchem e formam
lagoas; em volta delas nasce a **areia**. O leito do trilho virou **brita** (antes era "pedra").

| Superfície | Efeito |
|---|---|
| `agua` | velocidade 35%, grip 30%; acima de 15 m/s entra em aquaplanagem |
| `areia` | velocidade 50%, grip 42% |
| `brita` | velocidade 65%, grip 55%, tremor solto |
| `gelo` | só com neve: grip 18% (o asfalto congela) |
| `asfalto molhado` | chuva: grip 62% e mais chiado no motor agudo |

Moedas e obstáculos **não nascem na água**, e a IA sai da água em direção à estrada em vez de
perseguir moeda.

### Faróis

Triângulo alterna desligado → baixo → alto. À noite, na neblina e na chuva, o farol **muda a
densidade da neblina** na câmera: sem farol você enxerga menos de verdade (e o controle dá um
clique curto ao trocar).

### Para-brisa e limpador

Na chuva (e na neblina) o vidro **embaça** com o tempo, mais rápido em alta velocidade. O
embaçamento é um overlay 2D sobre o jogo (névoa nas bordas + gotas). Segurar **Círculo** liga o
limpador: cada varredura limpa um arco do vidro, o controle pulsa no ritmo e a lightbar fica azul.
Fora da chuva o limpador **não limpa nada** — só range a seco.

### Como o controle foi ajustado

| Ponto | Antes | Agora |
|---|---|---|
| Zona morta | 0,2 por eixo (diagonais travavam) | 0,14 radial, reescalada (sem "pulo" ao sair do centro) |
| Curva do analógico | linear | expoente 1,5 (`vehicle.steerExp`): centro fino, extremo rápido |
| Direção em alta velocidade | giro fixo (derrubava o carro) | taxa cai com a velocidade: aceleração lateral nunca passa de 1,6 g |
| Ré | só por teclado | L2 parado por 0,25 s |
| Teclado | direção 0 ou 1 de uma vez | rampa de ~0,2 s |
| Batida em poste/árvore | velocidade ×0,4 a cada quadro (grudava) | só perde a parte que entra no obstáculo e desliza |
| Borda do mapa | velocidade ×0,3 por quadro | desliza ao longo da borda |
| Câmera | fixa atrás do carro | analógico direito, R3, campo de visão abre com a velocidade |
| Vibração | superfície e relevo | + aviso de trem, batida (força pelo impacto), derrapagem, moeda (por valor) |
| Gatilhos fora do mapeamento "standard" | exigiam os botões 6/7 para ler o curso (R2 ficava em 0 e o carro não andava) | leem o eixo 3/4, com o repouso **calibrado** em tempo real |
| Retorno ao acelerar | mudo abaixo de 0,5 m/s | ronco de motor proporcional ao acelerador desde o primeiro toque |

Todos os números estão em `CONFIG.input`, `CONFIG.vehicle` e `CONFIG.camera`.

## Se o carro não anda com o controle

Abra o painel com **F2**. A primeira seção, `ENTRADA`, responde por que o carro anda ou não:

| O que aparece | Significado | O que fazer |
|---|---|---|
| `NENHUM controle visível` | O navegador não está expondo o controle | Feche Steam / DS4Windows / qualquer app que "traduza" o controle e recarregue. Teste em `chrome://gamepad` |
| Controle listado, mas `mudo há` alguns segundos | O controle está conectado, porém **congelado** | Outro programa tomou o dispositivo; feche-o e recarregue. Cabo: experimente outra porta USB |
| `mapping (vazio)` | O navegador não reconheceu o modelo como padrão | Funciona: o jogo normaliza o DirectInput |
| `acel 0.00` com R2 apertado | O gatilho não está chegando ao jogo | Se `mapping` é vazio, o eixo de repouso ainda não foi calibrado: solte o gatilho por um instante |
| `acel 1.00` e o carro parado | O controle está certo; o problema é outro | Verifique se a partida não está pausada (visibilidade da aba) |

Também dá para rodar o diagnóstico sem navegador, com um DualSense simulado:

```bash
npm run diag
```

Ele roda o pipeline real (`Input` → `PlayerDriver` → `Vehicle`) e mostra a velocidade final. Se o carro anda ali, a lógica está certa e o problema é a entrega do dispositivo ao navegador.


## Vibração: como testar

A vibração depende do navegador e do controle. O jogo mostra o diagnóstico no painel (F2):

1. Clique em **Começar**. Se a Gamepad API não expuser vibração, o navegador abre um seletor de dispositivo WebHID. O botão **Conectar DualSense USB** permite tentar novamente.
2. Selecione o DualSense autorizado e conecte-o por **USB**. A primeira conexão pede permissão; as próximas reutilizam essa autorização.
3. Abra **F2**: deve aparecer `WebHID USB conectado`. **F3** dispara o teste; falhas aparecem em `último erro`.
4. Bluetooth ainda não é suportado no caminho WebHID deste projeto.

Se o atuador estiver disponível e você ainda não sentir nada, o problema está na intensidade ou na própria via de 2 motores (ver "Limites").

### Parâmetros hápticos

Os efeitos ficam em `HAPTIC_PARAMS` em `src/haptics/haptics.js`; a vibração contínua por superfície fica em `SURFACES` em `src/core/config.js`. Intensidades vão de 0 a 1 e duração é em milissegundos.

| Efeito | Grave | Agudo | Duração |
|---|---:|---:|---:|
| Teste/colisão forte | 1,00 | 1,00 | 500 ms |
| Voltar à pista | 0,30 | 0,30 | 120 ms |
| Batida | 0,35 + impacto/14 | 0,70 | 160 ms |
| Moeda | 0,10 + valor×0,05 | 0,50 + valor×0,10 | 70 + valor×25 ms |
| Superfície/relevo | conforme superfície e velocidade | conforme superfície/clima/derrapagem | 120 ms, repetido a cada 100 ms |

## Arquitetura

As partes conversam por contratos e eventos. Nenhuma camada conhece os detalhes de outra.

```
CAMADA 1: Regras       Match (tempo, placar, rodadas)
                           │ controla
CAMADA 2: Simulação    Terreno ◄── consulta ── Veículos ── colide ── Trem (distância real)
                       (relevo suavizado,      ▲ (Driver: jogador ou IA)   │
                        estrada, trilho,       │ ◄── sinais (verde/aviso/vermelho)
                        obstáculos, moedas     │
                        por zona)              │
                       └──── Clima ────────────┘ (atrito, visibilidade)
                           │ eventos: coin:collected, vehicle:crash, vehicle:bump,
                           │          vehicle:reset, match:pause, weather:change
CAMADA 3: Apresentação Háptica · Câmera · HUD · render/* (Three.js)
```

### Relevo, estrada e trilho

- O relevo fora da pista é o ruído natural (`rawHeight`).
- Um **relevo suavizado** (`Ground`) é pré-calculado sobre uma grade e alisado com média de 28 m.
- Estrada e trilho se assentam nesse relevo suavizado, e o terreno se molda a eles nas margens.
- Resultado: a inclinação do trilho fica em ~4,4% e da estrada em ~8%, e nos cruzamentos as duas bases ficam à mesma altura (diferença de 1 cm). O terreno fora da pista continua variado.

### Pastas

```
index.html            página, tela inicial e importmap do Three.js
src/
├── core/             config.js (todos os números), surfaces.js (piso + clima), events, random
├── world/            noise, ground (relevo suavizado), terrain (nível de água), coins, train, props
├── vehicles/         vehicle (física + câmbio + faróis), drivers (jogador e IA)
├── input/            teclado e controle PS5 (toque × segurar, marcha, farol, limpador)
├── haptics/          perfis por superfície, mixer, gatilhos e LEDs de RPM + diagnóstico
├── gameplay/         match (rodadas, placar, regras), cabin (névoa e limpador)
├── ui/               hud (DOM)
├── render/           só desenho: terrainView, trackView, propsView, trainView,
│                     vehicleView, coinView, sky, weatherView, cabinView, materials
└── main.js           monta tudo e roda o loop
tests/                lógica, controle, háptica, entrada, marchas, superfícies, cabine, imports
```

`world/`, `vehicles/`, `gameplay/` e `core/` não importam Three.js. Isso permite testar a lógica no Node e trocar a visual sem mexer nas regras.

### Trem

- A cabeça anda pelo trilho. Cada carro tem frente e traseira sobre o trilho, e daí saem rumo, **inclinação** (sobe e desce) e **rolagem** (desnível entre os trilhos).
- A cabeça anda por **distância real** sobre o trilho (`train.s`, em metros), a 20 m/s em qualquer ponto. Antes avançava o ângulo e chegava a ~27 m/s no trecho mais afastado do "8".
- `train.signals()` diz, para cada cruzamento, se está `green`, `warn` (trem chega em até 6 s) ou `red` (trem passando). A IA freia nesses sinais, o HUD avisa o jogador, o controle vibra e os sinais piscam no cenário.
- Cada **eixo** fica sobre o trilho no seu próprio ponto. Assim as rodas encostam no trilho mesmo em curvas.
- As rodas giram conforme a distância percorrida.

### Modo de desenvolvimento

`index.html?dev` expõe `window.game` (estado do jogo) e permite câmera livre (`game.setDevCam`). Não afeta quem joga normalmente.

## Escala de referência

1 unidade = 1 metro.

| Item | Tamanho (aprox.) | Observação |
|---|---|---|
| Carro | 4,0 × 1,8 × 1,7 m | |
| Casa | 6 × 5 × 5,8 m | referência para o resto |
| Pinheiro | 6 a 10 m | |
| Carvalho | 6 a 9 m | |
| Poste de luz | 6,3 m | |
| Poste de telégrafo | 8 m | |
| Locomotiva | 16 m | |
| Vagão | 12 m | |
| Bitola | 1,435 m (trilhos a ±0,72 m) | padrão real |
| Moeda | diâmetro 1,8 m | **exagerada de propósito**, para ficar legível de longe |

## Como modificar cada elemento

| Quero mudar... | Onde mexer |
|---|---|
| Amplitude e largura do relevo | `CONFIG.terrain` (`heightScale`, `noiseScale`, `groundBlur`) |
| Largura ou curvatura da estrada | `CONFIG.road` |
| Forma do trilho ou cruzamentos | `CONFIG.rail` (`radiusBase`, `radiusAmp`) |
| Brita, dormentes, bitola | `CONFIG.rail` |
| Velocidade, aceleração, freio, suspensão | `CONFIG.vehicle` |
| Velocidade, vagões, posição dos eixos | `CONFIG.train` (`cars`, `wheelsets`) |
| Atrito, velocidade e vibração por superfície | `SURFACES` em `core/config.js` |
| Climas (céu, neblina, chuva, neve, noite) | `WEATHER` em `core/config.js` |
| Onde as moedas nascem e quanto valem | `CONFIG.coins.zones` (pesos), `hillSlope`, `riskDistance` e `coinValue` em `SURFACES` |
| Zona morta, curva e suavização do controle | `CONFIG.input` e `vehicle.steerExp` |
| Câmera (distância, campo de visão, giro) | `CONFIG.camera` |
| Sinais do trem | `CONFIG.train.warnSeconds`; visual em `render/roadsideView.js` |
| Quantidade de árvores, casas, pedras | `CONFIG.props` |
| Dificuldade da IA | `CONFIG.ai` (`levels`, `defaultLevel`, `coinSight`, `rubberLead`, `rubberTrail`) |
| Comportamento da IA | `AIDriver` em `vehicles/drivers.js` (mesma interface do jogador) |
| Regras de placar e penalidade | `gameplay/match.js` |
| Intensidade e padrão da vibração | `haptics/haptics.js` |
| Aparência de carro, trem, casa, árvore | `render/*View.js` (não afeta a lógica) |

Para trocar uma peça por outra, basta respeitar o contrato. Por exemplo, um novo Driver precisa apenas de `controls(vehicle, dt)` devolvendo `{ throttle, brake, steer }`.

## Convenções

- Direção: `heading = 0` aponta para +Z. Vetor da direção: `(sin h, cos h)`.
- `steer > 0` é para a esquerda.
- Simulação em passo fixo de 1/60 s (`STEP` em `main.js`).
- `pitch` positivo: frente mais alta. `roll` positivo: direita mais alta.

## Limites conhecidos

- **Vibração:** o jogo usa os dois motores padrão. Usa Gamepad API quando disponível e WebHID como alternativa no DualSense. O caminho WebHID implementa **USB (0x02) e Bluetooth (0x31, com CRC32)**, e os gatilhos adaptáveis são enviados em ambos. O que ainda não existe é háptica de gatilho com áudio (vozes/efeitos no atuador de gatilho).
- **Testes com controle:** não há controle no ambiente de desenvolvimento. A vibração foi verificada só até o ponto de diagnóstico; os caminhos de input e de relatório são cobertos por testes com controles falsos.
- **Trem e carro:** a colisão usa três pontos por vagão e raio fixo. É suficiente para o protótipo.
- **IA:** escolhe a moeda por valor/distância, desvia de obstáculos, foge da água e freia nos sinais. **Não tem navmesh — e isso foi medido, não suposto:** uma grade + A* foi implementada e comparada em 8 partidas de 210 s; ela perdeu para o desvio local (22,5 e 16,6 moedas contra 27,0 da IA original). O código foi removido e o banco de medição ficou (`npm run ia`). Hoje ela fica presa ~10 s por partida (≈5%), em episódios curtos, e se recupera sozinha (ré cada vez mais longa, abandona a moeda).
- **Cruzamento:** os sinais piscam, mas não há cancela nem ponte. O trem continua sendo um perigo real.
- **WebHID:** requer Chrome/Edge, contexto seguro (localhost ou HTTPS), permissão explícita e conexão com o controle. A vibração em hardware ainda não foi validada nesta máquina.

## Testes

```bash
npm test          # 103 testes + checagem das malhas visuais
npm run diag      # diagnóstico do input com DualSense simulado (sem navegador)
npm run ia        # mede a IA em 8 partidas: moedas, tempo presa, distância
npm run analise   # mede o mapa e escreve docs/analise-mapa.json
python3 tools/plot-map.py   # desenha docs/mapa-analise.png
```

No Windows, se `npm test` falhar com "execução de scripts foi desabilitada", rode direto: `node --test tests/logic.test.js tests/controle.test.js tests/haptics.test.js tests/entrada.test.js tests/marchas.test.js tests/superficies.test.js tests/cabine.test.js tests/ia.test.js tests/imports.test.js`.

`npm run ia` é o juiz das mudanças na IA: roda 8 partidas de 210 s e imprime moedas coletadas, episódios presa, segundos presos e distância. Qualquer "melhoria" que não melhore esses números deve ser descartada — foi o que aconteceu com a tentativa de A*.

`tests/imports.test.js` é uma trava estática: falha se algum módulo usar `CONFIG`, `SURFACES`, `WEATHER`, `EventBus`, `createRng` ou `THREE` sem importar. Foi assim que o `sound.js` passou a ser verificado — ele usava `CONFIG` sem import, e o `ReferenceError` dentro do loop de animação congelava o jogo inteiro.

Cobertura: relevo reproduzível, inclinação de trilho e estrada, cruzamentos, eixos sobre o trilho, trem com velocidade constante, sinais coerentes com a colisão, zona morta e curva do analógico, mapeamento do DualSense com controle falso, gatilhos lidos pelo eixo quando o navegador não usa mapeamento "standard", escolha da coleção HID correta (gamepad e não mouse), diagnóstico de controle congelado, ré, batida deslizante, limite de aceleração lateral, freio de mão, moedas por zona, IA (níveis, elástico, parada no sinal), pausa e "voltar à pista".

Novos: relações de marcha e curva de torque, troca automática por fração de faixa, troca manual desligando o automático, embreagem e evento de troca, RPM na largada, ciclo de faróis, perfis de superfície completos, chuva/neve alterando aderência, nível de água abaixo do leito da estrada, moedas e obstáculos fora da água, carro mais lento na água, névoa só na chuva, limpador limpando e limpador a seco inócuo, inversões de curso do limpador.

## Análise do mapa

`tools/map-analysis.mjs` trata o mapa como espaço de jogo e mede: uso do espaço, onde as moedas nascem, quem pega o quê (IA em 8 mapas × 210 s), exposição ao trem, visibilidade das moedas e obstáculos na pista. Resultado e decisões: `docs/analise-mapa.md`. Valores de antes: `docs/analise-antes.json`.

![mapa](docs/mapa-analise.png)
