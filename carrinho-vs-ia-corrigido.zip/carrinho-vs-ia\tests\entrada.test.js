// Testes de regressão da entrada: o caso que deixava o carro parado no controle.
//
// Contexto: quando o navegador entrega o DualSense SEM mapeamento "standard"
// (DirectInput cru), alguns drivers expõem o curso dos gatilhos apenas nos eixos,
// sem atualizar os botões 6/7. O código antigo exigia o botão para ler o gatilho,
// então R2 virava 0 e o carro nunca acelerava.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizePad,
  readPad,
  diagnoseInput,
  describeInputHealth,
  diagnosePad,
} from '../src/input/input.js';
import { pickGamepadDevice } from '../src/haptics/dualsense.js';

// DualSense em DirectInput: 8 eixos, gatilhos nos eixos 3 e 4 (-1 solto, +1 apertado).
// Cada teste usa um id próprio porque a calibração do repouso é por controle.
function directInputPad({ id = 'di', l2 = -1, r2 = -1, lx = 0, ly = 0 } = {}) {
  return {
    // O id precisa se parecer com o de um DualSense (é o que ativa a normalização)
    id: `${id} Wireless Controller (Vendor: 054c Product: 0ce6)`,
    connected: true,
    mapping: '', // não é "standard"
    axes: [lx, ly, 0, l2, r2, 0, 0, 0],
    buttons: Array.from({ length: 11 }, () => ({ pressed: false, value: 0 })),
  };
}

// Repouso observado uma vez (é o que acontece no primeiro quadro com o gatilho solto)
const calibrate = (pad) => normalizePad({ ...pad, axes: [0, 0, 0, -1, -1, 0, 0, 0] });

test('DirectInput sem botões 6/7: R2 no eixo acelera (antes ficava mudo em 0)', () => {
  const id = 'di-r2';
  calibrate(directInputPad({ id }));
  const controls = readPad(normalizePad(directInputPad({ id, r2: 1 })));
  assert.ok(controls.throttle > 0.95, `R2 no eixo deve acelerar, veio ${controls.throttle}`);
  assert.equal(controls.brake, 0, 'L2 solto não pode frear');
});

test('DirectInput: L2 no eixo freia e R2 solto não acelera', () => {
  const id = 'di-l2';
  calibrate(directInputPad({ id }));
  const controls = readPad(normalizePad(directInputPad({ id, l2: 1, r2: -1 })));
  assert.ok(controls.brake > 0.95, `L2 no eixo deve frear, veio ${controls.brake}`);
  assert.equal(controls.throttle, 0, 'R2 solto (-1) não pode acelerar');
});

test('DirectInput: eixo que fica em 0 no repouso não gera aceleração fantasma', () => {
  // Controle cujo eixo parado vale 0 em vez de -1: sem ter visto -1, o eixo é ignorado
  const id = 'di-zero-rest';
  const controls = readPad(normalizePad(directInputPad({ id, r2: 0, l2: 0 })));
  assert.equal(controls.throttle, 0, 'não pode acelerar sozinho');
  assert.equal(controls.brake, 0, 'não pode frear sozinho');
});

test('DirectInput com botões 6/7 continua funcionando pelo caminho antigo', () => {
  const pad = directInputPad({ id: 'di-btns', r2: 1 });
  pad.buttons[6] = { pressed: false, value: 0 };
  pad.buttons[7] = { pressed: true, value: 1 };
  const controls = readPad(normalizePad(pad));
  assert.ok(controls.throttle > 0.95);
});

test('DirectInput: analógico esquerdo continua dirigindo e acelerando', () => {
  const left = readPad(normalizePad(directInputPad({ id: 'di-steer', lx: 1, ly: 0 })));
  assert.ok(left.steer < -0.9, 'analógico para a direita = steer negativo');

  const fwd = readPad(normalizePad(directInputPad({ id: 'di-steer', lx: 0, ly: -1 })));
  assert.ok(fwd.throttle > 0.9, 'analógico para frente acelera sem gatilho');
});

test('pickGamepadDevice: escolhe a coleção de gamepad (usage 0x05), não a do mouse (0x04)', () => {
  const mouse = { id: 'mouse', collections: [{ usagePage: 0x01, usage: 0x04 }] };
  const gamepad = { id: 'gamepad', collections: [{ usagePage: 0x01, usage: 0x05 }] };
  const audio = { id: 'audio', collections: [{ usagePage: 0x0c, usage: 0x01 }] };

  assert.equal(pickGamepadDevice([mouse, gamepad, audio]).id, 'gamepad');
  assert.equal(pickGamepadDevice([gamepad, mouse]).id, 'gamepad');
  assert.equal(pickGamepadDevice([mouse, audio]).id, 'mouse', 'sem gamepad, aceita 0x04');
  assert.equal(pickGamepadDevice([]), null);
  assert.equal(pickGamepadDevice([audio]).id, 'audio', 'último recurso: primeiro da lista');
});

test('diagnóstico: nenhum controle visível explica o sintoma', () => {
  assert.match(describeInputHealth([]), /NENHUM controle/i);
});

test('diagnóstico: controle congelado é identificado (Steam/DS4Windows tomando o dispositivo)', () => {
  const frozen = [
    {
      source: 'gamepad',
      index: 0,
      id: 'DualSense',
      mapping: 'standard',
      throttle: 0,
      brake: 0,
      steer: 0,
      ageMs: 12_000,
    },
  ];
  assert.match(describeInputHealth(frozen), /CONGELADOS/i);
});

test('diagnóstico: controle vivo e acelerando é reconhecido', () => {
  const live = [
    {
      source: 'gamepad',
      index: 0,
      id: 'DualSense',
      mapping: 'standard',
      throttle: 0.8,
      brake: 0,
      steer: 0,
      ageMs: 16,
    },
  ];
  assert.match(describeInputHealth(live), /Entrada ativa via gamepad/i);
});

test('diagnosePad: lê os valores e conta o tempo sem mudança', () => {
  const pad = {
    id: 'DualSense',
    connected: true,
    mapping: 'standard',
    axes: [0, 0, 0, 0],
    buttons: Array.from({ length: 17 }, () => ({ pressed: false, value: 0 })),
  };
  pad.buttons[7] = { pressed: true, value: 1 };

  const row = diagnosePad(pad, 'gamepad', 0);
  assert.equal(row.source, 'gamepad');
  assert.equal(row.mapping, 'standard');
  assert.ok(row.throttle > 0.95);
  assert.ok(row.buttons >= 1);
  assert.ok(row.ageMs >= 0);
});

test('diagnoseInput: Gamepad API aparece como fonte', () => {
  const origNav = globalThis.navigator;
  const fake = {
    id: 'DualSense (STANDARD GAMEPAD Vendor: 054c Product: 0ce6)',
    connected: true,
    mapping: 'standard',
    axes: [0, 0, 0, 0],
    buttons: Array.from({ length: 17 }, () => ({ pressed: false, value: 0 })),
  };
  Object.defineProperty(globalThis, 'navigator', {
    value: { getGamepads: () => [fake] },
    configurable: true,
  });
  try {
    const rows = diagnoseInput();
    assert.equal(rows.length, 1);
    assert.equal(rows[0].source, 'gamepad');
  } finally {
    Object.defineProperty(globalThis, 'navigator', { value: origNav, configurable: true });
  }
});
