// Superfícies: perfis, clima e água no mapa.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CONFIG, SURFACES } from '../src/core/config.js';
import { effectiveSurface, SURFACE_KEYS } from '../src/core/surfaces.js';
import { Terrain } from '../src/world/terrain.js';
import { Props } from '../src/world/props.js';
import { CoinField } from '../src/world/coins.js';
import { Vehicle } from '../src/vehicles/vehicle.js';
import { createRng } from '../src/core/random.js';

const terrain = new Terrain(CONFIG.seed);
const sol = { id: 'sol' };
const chuva = { id: 'chuva' };
const neve = { id: 'neve' };

test('toda superfície tem perfil completo (física + háptica)', () => {
  for (const key of SURFACE_KEYS) {
    const s = SURFACES[key];
    assert.ok(typeof s.label === 'string' && s.label.length > 0, `${key}: label`);
    assert.ok(s.grip >= 0 && s.grip <= 1, `${key}: grip 0..1`);
    assert.ok(s.speedFactor > 0, `${key}: speedFactor`);
    assert.ok(typeof s.strong === 'number' && typeof s.weak === 'number', `${key}: motores`);
    assert.ok(typeof s.textureHz === 'number' && typeof s.grain === 'number', `${key}: textura`);
    assert.ok(typeof s.color === 'number', `${key}: cor`);
  }
});

test('chuva reduz o grip e engrossa o motor agudo', () => {
  const seco = effectiveSurface('asfalto', sol);
  const molhado = effectiveSurface('asfalto', chuva);
  assert.ok(molhado.grip < seco.grip, 'asfalto molhado agarra menos');
  assert.ok(molhado.weak > seco.weak, 'piso molhado tem mais chiado');
  assert.equal(molhado.wet, true);
});

test('neve transforma o asfalto em gelo', () => {
  const gelo = effectiveSurface('asfalto', neve);
  assert.equal(gelo.frozen, true);
  assert.ok(gelo.grip < 0.25, `grip de gelo deveria ser baixíssimo, veio ${gelo.grip}`);
  assert.ok(gelo.label.toLowerCase().includes('gelo'));
});

test('lama e água não são "molhadas" pelo clima (já são)', () => {
  assert.equal(effectiveSurface('lama', chuva).wet, false);
  assert.equal(effectiveSurface('agua', chuva).wet, false);
});

test('o nível da água fica abaixo de todo o leito da estrada', () => {
  for (let i = 0; i < 240; i++) {
    const theta = (i / 240) * Math.PI * 2;
    const p = terrain.roadPoint(theta);
    assert.ok(
      terrain.heightAt(p.x, p.z) > terrain.waterLevel,
      `pista alagada em theta=${theta.toFixed(3)}`
    );
  }
});

test('água só aparece onde a profundidade é positiva', () => {
  let vistos = 0;
  for (let i = 0; i < 4000; i++) {
    const x = (Math.random() - 0.5) * (terrain.size - 20);
    const z = (Math.random() - 0.5) * (terrain.size - 20);
    if (terrain.surfaceAt(x, z) === 'agua') {
      vistos++;
      assert.ok(terrain.waterDepthAt(x, z) > 0, 'água sem profundidade');
    }
  }
  assert.ok(vistos > 0, 'o mapa precisa ter água');
});

test('surfaceAt sempre devolve uma superfície conhecida', () => {
  for (let i = 0; i < 3000; i++) {
    const x = (Math.random() - 0.5) * (terrain.size - 20);
    const z = (Math.random() - 0.5) * (terrain.size - 20);
    assert.ok(SURFACES[terrain.surfaceAt(x, z)], `superfície desconhecida em ${x},${z}`);
  }
});

test('moedas nunca nascem dentro da água', () => {
  const props = new Props(terrain);
  props.generate(createRng(CONFIG.seed + 1));
  const coins = new CoinField(terrain, props);
  coins.reset(createRng(CONFIG.seed + 2), []);
  for (const c of coins.coins) {
    assert.notEqual(terrain.surfaceAt(c.x, c.z), 'agua', `moeda ${c.id} caiu na água`);
  }
});

test('obstáculos não nascem na água', () => {
  const props = new Props(terrain);
  props.generate(createRng(CONFIG.seed + 1));
  for (const item of props.items) {
    assert.notEqual(terrain.surfaceAt(item.x, item.z), 'agua', `${item.kind} na água`);
  }
});

test('aquaplanagem: o perfil de água expõe a velocidade crítica', () => {
  const agua = effectiveSurface('agua', sol);
  assert.ok(Number.isFinite(agua.aquaplane), 'água precisa de velocidade de aquaplanagem');
  assert.ok(agua.aquaplane > 0);
});

test('na água o carro anda bem menos que no asfalto', () => {
  // 1,2 s é o bastante para a diferença de atrito aparecer sem o carro sair da água
  const run = (x, z) => {
    const car = new Vehicle({
      id: 'teste',
      terrain,
      driver: { controls: () => ({ throttle: 1, brake: 0, steer: 0, handbrake: false }) },
    });
    car.place(x, z, 0);
    for (let i = 0; i < Math.round(1.2 * 60); i++) {
      car.update(1 / 60, { id: 'sol', grip: 1, hapticWeak: 0 });
    }
    return Math.abs(car.speed);
  };

  const road = terrain.roadPoint(0);
  const noAsfalto = run(road.x, road.z);

  // Busca determinística por um ponto de água (nada de Math.random no teste)
  let ponto = null;
  for (let i = 0; i < 200 && !ponto; i++) {
    for (let j = 0; j < 200 && !ponto; j++) {
      const x = -terrain.half + 10 + i * 2.5;
      const z = -terrain.half + 10 + j * 2.5;
      if (terrain.surfaceAt(x, z) === 'agua') ponto = { x, z };
    }
  }
  assert.ok(ponto, 'o mapa precisa ter água');
  const naAgua = run(ponto.x, ponto.z);
  assert.ok(
    naAgua < noAsfalto * 0.7,
    `água deveria ser bem mais lenta (água ${naAgua.toFixed(2)} m/s, asfalto ${noAsfalto.toFixed(2)} m/s)`
  );
});
