// Trava contra a classe de bug que congelava o jogo:
// usar um símbolo compartilhado (CONFIG, SURFACES...) sem importá-lo.
// Optional chaining não protege variável inexistente: `CONFIG?.rail` lança ReferenceError.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'src');

// Símbolos que vêm de outro módulo e nunca podem aparecer soltos
const SHARED = ['CONFIG', 'SURFACES', 'WEATHER', 'EventBus', 'createRng', 'THREE'];

function walk(dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out);
    else if (entry.name.endsWith('.js')) out.push(full);
  }
  return out;
}

// Remove comentários e literais de string para não confundir texto com código
function codeOnly(source) {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .replace(/\/\/[^\n]*/g, ' ')
    .replace(/'(?:\\.|[^'\\])*'/g, "''")
    .replace(/"(?:\\.|[^"\\])*"/g, '""')
    .replace(/`(?:\\.|[^`\\])*`/g, '``');
}

const files = walk(ROOT);

test('existe código para analisar', () => {
  assert.ok(files.length > 10, `esperava vários módulos, achei ${files.length}`);
});

for (const symbol of SHARED) {
  test(`todo uso de ${symbol} tem import ou definição local`, () => {
    const problemas = [];
    for (const file of files) {
      const code = codeOnly(fs.readFileSync(file, 'utf8'));
      const usado = new RegExp(`\\b${symbol}\\b`).test(code);
      if (!usado) continue;

      const importado = new RegExp(`import[^;]*\\b${symbol}\\b`).test(code);
      const definido = new RegExp(
        `(?:export\\s+)?(?:const|let|var|function|class)\\s+${symbol}\\b`
      ).test(code);
      if (!importado && !definido) {
        problemas.push(path.relative(ROOT, file));
      }
    }
    assert.deepEqual(problemas, [], `usam ${symbol} sem importar: ${problemas.join(', ')}`);
  });
}
