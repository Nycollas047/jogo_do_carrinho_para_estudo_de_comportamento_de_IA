// Câmbio: relações, torque, troca automática/manual, ré e faróis.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CONFIG } from '../src/core/config.js';
import { Terrain } from '../src/world/terrain.js';
import { Vehicle, torqueAt, speedAtRpm } from '../src/vehicles/vehicle.js';

const terrain = new Terrain(CONFIG.seed);
const gb = CONFIG.gearbox;

function makeCar() {
  const p = terrain.roadPoint(0);
  const car = new Vehicle({
    id: 'teste',
    terrain,
    driver: { controls: () => ({ throttle: 1, brake: 0, steer: 0, handbrake: false }) },
  });
  car.place(p.x, p.z, 0);
  return car;
}

test('relações de marcha são decrescentes e a ré é curta', () => {
  for (let i = 1; i < gb.ratios.length; i++) {
    assert.ok(gb.ratios[i] < gb.ratios[i - 1], `marcha ${i + 1} deve ser mais longa que a ${i}`);
  }
  assert.ok(gb.reverseRatio > 0);
});

test('speedAtRpm: a velocidade cresce com o RPM e cai com a relação', () => {
  const low = speedAtRpm(3000, gb.ratios[0]);
  const high = speedAtRpm(6000, gb.ratios[0]);
  assert.ok(high > low);
  const longGear = speedAtRpm(6000, gb.ratios[4]);
  assert.ok(longGear > high, 'marcha longa = mais velocidade no mesmo RPM');
});

test('curva de torque: pico no meio, cai nas pontas', () => {
  const idle = torqueAt(800);
  const peak = torqueAt(4200);
  const redline = torqueAt(6800);
  assert.ok(peak > idle && peak > redline);
  assert.equal(peak, 1);
  assert.ok(torqueAt(10000) === torqueAt(6800), 'acima da tabela usa o último ponto');
});

test('automático sobe de marcha perto do fim da faixa', () => {
  const car = makeCar();
  car.gear = 1;
  car.autoShift = true;
  const top1 = speedAtRpm(gb.redline, gb.ratios[0]);

  car.speed = top1 * 0.5;
  car._updateGearbox(1 / 60, 1);
  assert.equal(car.gear, 1, 'no meio da faixa não troca');

  car.speed = top1 * 0.95;
  car._updateGearbox(1 / 60, 1);
  assert.equal(car.gear, 2, 'perto do limite sobe');
});

test('automático desce de marcha quando perde velocidade', () => {
  const car = makeCar();
  car.gear = 3;
  car.autoShift = true;
  car.speed = 3;
  car._updateGearbox(1 / 60, 1);
  assert.equal(car.gear, 2, 'devia descer de 3 para 2');
});

test('troca manual desliga o automático e respeita os limites', () => {
  const car = makeCar();
  car.gear = 1;
  car.autoShift = true;
  assert.equal(car.shiftUp(), true);
  assert.equal(car.gear, 2);
  assert.equal(car.autoShift, false, 'primeira troca manual assume o controle');

  car.gear = gb.ratios.length;
  assert.equal(car.shiftUp(), false, 'não passa da última marcha');
});

test('ré engata ao pedir ré e volta ao andar para frente', () => {
  const car = makeCar();
  car._updateGearbox(1 / 60, -1);
  assert.equal(car.gear, -1);
  assert.ok(car.gearRatio() === gb.reverseRatio);

  car.speed = 0.2;
  car._updateGearbox(1 / 60, 1);
  assert.equal(car.gear, 1, 'com o carro quase parado volta para a 1ª');
});

test('troca de marcha abre a embreagem e registra o evento', () => {
  const car = makeCar();
  car.gear = 1;
  car.shiftUp();
  assert.ok(car.shiftTimer > 0, 'embreagem aberta por shiftTime');
  assert.deepEqual(
    { from: car.gearShift.from, to: car.gearShift.to, up: car.gearShift.up },
    { from: 1, to: 2, up: true }
  );
});

test('faróis: ciclo desligado → baixo → alto → desligado', () => {
  const car = makeCar();
  assert.equal(car.lights, 0);
  assert.equal(car.cycleLights(), 1);
  assert.equal(car.cycleLights(), 2);
  assert.equal(car.cycleLights(), 0);
});

test('RPM sobe com o acelerador mesmo parado (embreagem patinando)', () => {
  const car = makeCar();
  car.speed = 0;
  car.rpm = gb.idleRpm;
  for (let i = 0; i < 60; i++) car._updateGearbox(1 / 60, 1);
  assert.ok(car.rpm > gb.idleRpm + 100, `rpm deveria subir, veio ${car.rpm}`);
});

test('RPM nunca é negativo nem NaN em 20 s de simulação', () => {
  const car = makeCar();
  const driver = { throttle: 1, brake: 0, steer: 0, handbrake: false };
  for (let i = 0; i < 1200; i++) {
    car.driver = { controls: () => driver };
    car.update(1 / 60, { id: 'sol', grip: 1, hapticWeak: 0 });
    assert.ok(Number.isFinite(car.rpm) && car.rpm >= 0);
    assert.ok(Number.isFinite(car.speed));
    assert.ok(car.gear >= -1 && car.gear <= 5);
  }
});
